﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace VetPatitasFelices.Data
{
    public class Conexion
    {
        // Asegúrate de cambiar "TuServidor" por el nombre de tu instancia SQL Server o LocalDB
        private string cadenaConexion = "Server=(localdb)\\MSSQLLocalDB;Database=VetPatitasFelices;Integrated Security=true;";

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}
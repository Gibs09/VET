﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


using VetPatitasFelices.Views; // <-- 1. Agrega esta línea para importar tus vistas

namespace VetPatitasFelices
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 2. Cambia FCliente() por Login() para que sea la primera pantalla en abrir
            Application.Run(new Login());
        }
    }
}

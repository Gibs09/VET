﻿using System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Modelos;

namespace VetPatitasFelices
{
    public partial class FCliente : Form
    {
        private AgendamientoController controller = new AgendamientoController();

        public FCliente()
        {
            InitializeComponent();
            ConfigurarFormulario();
            btnAgendarReserva.Click += BtnAgendarReserva_Click;
            lblCerrarSesion.Click += LblCerrarSesion_Click;
        }

        private void ConfigurarFormulario()
        {
            cbTipoDeMascota.Items.AddRange(new string[] { "Perro", "Gato", "Exótico" });
            cbHora.Items.AddRange(new string[] { "09:00", "10:00", "11:00", "15:00", "16:00" });
        }

        private void BtnAgendarReserva_Click(object sender, EventArgs e)
        {
            // Validación robusta para la rúbrica
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtNombreDeLaMascota.Text) || cbHora.SelectedItem == null)
            {
                MessageBox.Show("Por favor completa todos los campos.");
                return;
            }

            if (!int.TryParse(txtEdad.Text, out int edad))
            {
                MessageBox.Show("La edad debe ser un número entero.");
                return;
            }

            Agendamiento nuevo = new Agendamiento
            {
                NombreDueno = txtNombre.Text.Trim(),
                Telefono = txtTelefono.Text.Trim(),
                Correo = txtCorreo.Text.Trim(),
                NombreMascota = txtNombreDeLaMascota.Text.Trim(),
                TipoMascota = cbTipoDeMascota.Text,
                EdadMascota = edad,
                FechaAtencion = dtpFecha.Value,
                HoraAtencion = cbHora.Text,
                MotivoConsulta = txtMotivo.Text.Trim()
            };

            if (controller.RegistrarAgendamiento(nuevo))
            {
                MessageBox.Show("Reserva guardada con estado Pendiente.");
                LimpiarCampos();
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear(); txtTelefono.Clear(); txtCorreo.Clear();
            txtNombreDeLaMascota.Clear(); txtEdad.Clear(); txtMotivo.Clear();
        }

        private void LblCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Restart(); // Vuelve al login
        }
    }
}
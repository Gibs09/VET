﻿namespace VetPatitasFelices
{
    partial class FCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.lblNombreDeLaMascota = new System.Windows.Forms.Label();
            this.lblEdad = new System.Windows.Forms.Label();
            this.lblTipoDeMascota = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtNombreDeLaMascota = new System.Windows.Forms.TextBox();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.cbTipoDeMascota = new System.Windows.Forms.ComboBox();
            this.btnAgendarReserva = new System.Windows.Forms.Button();
            this.lblCerrarSesion = new System.Windows.Forms.Button();
            this.cbHora = new System.Windows.Forms.ComboBox();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(12, 34);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(62, 16);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre :";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(12, 74);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(67, 16);
            this.lblTelefono.TabIndex = 1;
            this.lblTelefono.Text = "Telefono :";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Location = new System.Drawing.Point(12, 120);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(54, 16);
            this.lblCorreo.TabIndex = 2;
            this.lblCorreo.Text = "Correo :";
            // 
            // lblNombreDeLaMascota
            // 
            this.lblNombreDeLaMascota.AutoSize = true;
            this.lblNombreDeLaMascota.Location = new System.Drawing.Point(12, 193);
            this.lblNombreDeLaMascota.Name = "lblNombreDeLaMascota";
            this.lblNombreDeLaMascota.Size = new System.Drawing.Size(156, 16);
            this.lblNombreDeLaMascota.TabIndex = 3;
            this.lblNombreDeLaMascota.Text = "Nombre De La Mascota :";
            // 
            // lblEdad
            // 
            this.lblEdad.AutoSize = true;
            this.lblEdad.Location = new System.Drawing.Point(12, 244);
            this.lblEdad.Name = "lblEdad";
            this.lblEdad.Size = new System.Drawing.Size(46, 16);
            this.lblEdad.TabIndex = 4;
            this.lblEdad.Text = "Edad :";
            // 
            // lblTipoDeMascota
            // 
            this.lblTipoDeMascota.AutoSize = true;
            this.lblTipoDeMascota.Location = new System.Drawing.Point(12, 300);
            this.lblTipoDeMascota.Name = "lblTipoDeMascota";
            this.lblTipoDeMascota.Size = new System.Drawing.Size(117, 16);
            this.lblTipoDeMascota.TabIndex = 5;
            this.lblTipoDeMascota.Text = "Tipo De Mascota :";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(396, 77);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(51, 16);
            this.lblFecha.TabIndex = 6;
            this.lblFecha.Text = "Fecha :";
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Location = new System.Drawing.Point(396, 31);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(43, 16);
            this.lblHora.TabIndex = 7;
            this.lblHora.Text = "Hora :";
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Location = new System.Drawing.Point(394, 120);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(53, 16);
            this.lblMotivo.TabIndex = 8;
            this.lblMotivo.Text = "Motivo :";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(80, 28);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(168, 22);
            this.txtNombre.TabIndex = 9;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(85, 71);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(163, 22);
            this.txtTelefono.TabIndex = 10;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(72, 114);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(176, 22);
            this.txtCorreo.TabIndex = 11;
            // 
            // txtNombreDeLaMascota
            // 
            this.txtNombreDeLaMascota.Location = new System.Drawing.Point(174, 190);
            this.txtNombreDeLaMascota.Name = "txtNombreDeLaMascota";
            this.txtNombreDeLaMascota.Size = new System.Drawing.Size(134, 22);
            this.txtNombreDeLaMascota.TabIndex = 12;
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(64, 244);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(103, 22);
            this.txtEdad.TabIndex = 13;
            // 
            // cbTipoDeMascota
            // 
            this.cbTipoDeMascota.FormattingEnabled = true;
            this.cbTipoDeMascota.Items.AddRange(new object[] {
            "Perro ",
            "Gato",
            "Exótico",
            "Otro"});
            this.cbTipoDeMascota.Location = new System.Drawing.Point(135, 292);
            this.cbTipoDeMascota.Name = "cbTipoDeMascota";
            this.cbTipoDeMascota.Size = new System.Drawing.Size(153, 24);
            this.cbTipoDeMascota.TabIndex = 14;
            // 
            // btnAgendarReserva
            // 
            this.btnAgendarReserva.Location = new System.Drawing.Point(15, 384);
            this.btnAgendarReserva.Name = "btnAgendarReserva";
            this.btnAgendarReserva.Size = new System.Drawing.Size(155, 23);
            this.btnAgendarReserva.TabIndex = 15;
            this.btnAgendarReserva.Text = "Agendar   Reserva";
            this.btnAgendarReserva.UseVisualStyleBackColor = true;
            // 
            // lblCerrarSesion
            // 
            this.lblCerrarSesion.Location = new System.Drawing.Point(228, 384);
            this.lblCerrarSesion.Name = "lblCerrarSesion";
            this.lblCerrarSesion.Size = new System.Drawing.Size(152, 23);
            this.lblCerrarSesion.TabIndex = 16;
            this.lblCerrarSesion.Text = "Cerrar Sesion";
            this.lblCerrarSesion.UseVisualStyleBackColor = true;
            // 
            // cbHora
            // 
            this.cbHora.FormattingEnabled = true;
            this.cbHora.Location = new System.Drawing.Point(445, 26);
            this.cbHora.Name = "cbHora";
            this.cbHora.Size = new System.Drawing.Size(170, 24);
            this.cbHora.TabIndex = 17;
            this.cbHora.Text = "HH:MM";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(455, 72);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(160, 22);
            this.dtpFecha.TabIndex = 18;
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(453, 114);
            this.txtMotivo.Multiline = true;
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(188, 22);
            this.txtMotivo.TabIndex = 19;
            // 
            // FCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 511);
            this.Controls.Add(this.txtMotivo);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.cbHora);
            this.Controls.Add(this.lblCerrarSesion);
            this.Controls.Add(this.btnAgendarReserva);
            this.Controls.Add(this.cbTipoDeMascota);
            this.Controls.Add(this.txtEdad);
            this.Controls.Add(this.txtNombreDeLaMascota);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblMotivo);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.lblTipoDeMascota);
            this.Controls.Add(this.lblEdad);
            this.Controls.Add(this.lblNombreDeLaMascota);
            this.Controls.Add(this.lblCorreo);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.lblNombre);
            this.Name = "FCliente";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Label lblNombreDeLaMascota;
        private System.Windows.Forms.Label lblEdad;
        private System.Windows.Forms.Label lblTipoDeMascota;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtNombreDeLaMascota;
        private System.Windows.Forms.TextBox txtEdad;
        private System.Windows.Forms.ComboBox cbTipoDeMascota;
        private System.Windows.Forms.Button btnAgendarReserva;
        private System.Windows.Forms.Button lblCerrarSesion;
        private System.Windows.Forms.ComboBox cbHora;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.TextBox txtMotivo;
    }
}


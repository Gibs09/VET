﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;

// Autor: G1bs KP
// Sistema de Cine Lumière adaptado a Veterinaria Patitas Felices

using VetPatitasFelices.Modelos;

namespace VetPatitasFelices.Views
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            btnIniciarSesion.Click += BtnIniciarSesion_Click;
        }

        private void BtnIniciarSesion_Click(object sender, EventArgs e)
        {
            // Validacion de campos vacios
            if (string.IsNullOrWhiteSpace(txtUsuario.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Ingresa usuario y contraseña.");
                return;
            }

            UsuarioController control = new UsuarioController();
            string user = txtUsuario.Text.Trim();
            string pass = txtPass.Text.Trim();

            Usuario usuarioLogueado = control.ValidarUsuario(user, pass);

            if (usuarioLogueado != null)
            {
                MessageBox.Show("Bienvenido " + usuarioLogueado.NombreUsuario);

                // Validamos los roles para abrir la ventana correcta
                if (usuarioLogueado.Rol == "Administrador")
                {
                    FAdmin admin = new FAdmin();
                    admin.Show();
                }
                else if (usuarioLogueado.Rol == "Cliente")
                {
                    FCliente cliente = new FCliente();
                    cliente.Show();
                }

                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
    }
}
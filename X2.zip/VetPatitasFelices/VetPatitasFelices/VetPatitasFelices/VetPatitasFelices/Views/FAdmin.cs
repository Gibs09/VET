﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Modelos;

namespace VetPatitasFelices.Views
{
    public partial class FAdmin : Form
    {
        // Instancia del controlador para manejar los datos
        private AgendamientoController controller = new AgendamientoController();
        private int idSeleccionado = 0; // Variable global para saber qué fila estamos editando

        public FAdmin()
        {
            InitializeComponent();

            // Cargamos las opciones de los ComboBoxes al iniciar
            ConfigurarComboBoxes();

            // Cargamos la grilla con todos los datos
            ActualizarGrilla();

            // Suscribimos los eventos de los botones
            btnAgregar.Click += BtnAgregar_Click;
            btnActualizar.Click += BtnActualizar_Click;
            btnEliminar.Click += BtnEliminar_Click;
            btnCerrarSesion.Click += BtnCerrarSesion_Click;
            cbFiltrarEstado.SelectedIndexChanged += CbFiltrarEstado_SelectedIndexChanged;

            // Evento para cargar datos al hacer click en la tabla
            dataGridView1.CellClick += DataGridView1_CellClick;
        }

        private void ConfigurarComboBoxes()
        {
            // Opciones para el tipo de mascota (Nuevo cambio solicitado)
            cbTipoDeMascota.Items.Add("Perro");
            cbTipoDeMascota.Items.Add("Gato");
            cbTipoDeMascota.Items.Add("Exotico");

            // Opciones para editar el estado del agendamiento
            cbEditarEstado.Items.Add("Pendiente");
            cbEditarEstado.Items.Add("Confirmada");
            cbEditarEstado.Items.Add("Atendida");
            cbEditarEstado.Items.Add("Cancelada");

            // Opciones para el filtro de la parte superior/inferior
            cbFiltrarEstado.Items.Add("Todos");
            cbFiltrarEstado.Items.Add("Pendiente");
            cbFiltrarEstado.Items.Add("Confirmada");
            cbFiltrarEstado.Items.Add("Atendida");
            cbFiltrarEstado.Items.Add("Cancelada");
            cbFiltrarEstado.SelectedIndex = 0; // "Todos" por defecto
        }

        private void ActualizarGrilla(string filtro = "Todos")
        {
            dataGridView1.DataSource = controller.ObtenerAgendamientos(filtro);
        }

        // Metodo para capturar los datos de la fila seleccionada
        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dataGridView1.Rows[e.RowIndex];

                idSeleccionado = Convert.ToInt32(fila.Cells["IdAgendamiento"].Value);
                txtNombre.Text = fila.Cells["NombreDueno"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                txtCorreo.Text = fila.Cells["Correo"].Value.ToString();
                txtEdad.Text = fila.Cells["EdadMascota"].Value.ToString();
                txtNombreDeLaMascota.Text = fila.Cells["NombreMascota"].Value.ToString();

                // CAMBIO: Ahora usamos cbTipoDeMascota en vez del textbox
                cbTipoDeMascota.Text = fila.Cells["TipoMascota"].Value.ToString();

                txtMotivo.Text = fila.Cells["MotivoConsulta"].Value.ToString();
                dtpFecha.Value = Convert.ToDateTime(fila.Cells["FechaAtencion"].Value);
                cbEditarEstado.Text = fila.Cells["Estado"].Value.ToString();
            }
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            int edad = 0;
            int.TryParse(txtEdad.Text, out edad);

            Agendamiento ag = new Agendamiento
            {
                NombreDueno = txtNombre.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text,
                NombreMascota = txtNombreDeLaMascota.Text,

                // CAMBIO: Capturamos el texto del ComboBox
                TipoMascota = cbTipoDeMascota.Text,

                EdadMascota = edad,
                FechaAtencion = dtpFecha.Value,
                MotivoConsulta = txtMotivo.Text,
                HoraAtencion = "12:00" // Valor por defecto para admin
            };

            if (controller.RegistrarAgendamiento(ag))
            {
                MessageBox.Show("Mascota agregada con éxito.");
                ActualizarGrilla();
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Por favor, selecciona una mascota de la tabla.");
                return;
            }

            int edad = 0;
            int.TryParse(txtEdad.Text, out edad);

            Agendamiento ag = new Agendamiento
            {
                IdAgendamiento = idSeleccionado,
                NombreDueno = txtNombre.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text,
                NombreMascota = txtNombreDeLaMascota.Text,

                // CAMBIO: Capturamos el texto del ComboBox actualizado
                TipoMascota = cbTipoDeMascota.Text,

                EdadMascota = edad,
                FechaAtencion = dtpFecha.Value,
                MotivoConsulta = txtMotivo.Text,
                Estado = cbEditarEstado.Text
            };

            if (controller.ActualizarAgendamiento(ag))
            {
                MessageBox.Show("Datos actualizados correctamente.");
                ActualizarGrilla();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado > 0)
            {
                var result = MessageBox.Show("¿Estás seguro de eliminar esta reserva?", "Confirmar", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    if (controller.EliminarAgendamiento(idSeleccionado))
                    {
                        ActualizarGrilla();
                        idSeleccionado = 0;
                        MessageBox.Show("Reserva eliminada.");
                    }
                }
            }
        }

        private void CbFiltrarEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarGrilla(cbFiltrarEstado.Text);
        }

        private void BtnCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
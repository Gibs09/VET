﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices.Data;
using VetPatitasFelices.Modelos;

namespace VetPatitasFelices.Controllers
{
    public class AgendamientoController
    {
        private Conexion conexion = new Conexion();

        public DataTable ObtenerAgendamientos(string estadoFiltro = "Todos")
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = estadoFiltro == "Todos" ?
                               "SELECT * FROM Agendamientos" :
                               "SELECT * FROM Agendamientos WHERE Estado = @estado";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (estadoFiltro != "Todos") cmd.Parameters.AddWithValue("@estado", estadoFiltro);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(tabla);
                }
            }
            return tabla;
        }

        public bool RegistrarAgendamiento(Agendamiento a)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"INSERT INTO Agendamientos 
                                (NombreDueno, Telefono, Correo, NombreMascota, TipoMascota, EdadMascota, FechaAtencion, HoraAtencion, MotivoConsulta, Estado) 
                                VALUES (@nd, @tel, @cor, @nm, @tm, @em, @fa, @ha, @mc, @est)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nd", a.NombreDueno);
                    cmd.Parameters.AddWithValue("@tel", a.Telefono);
                    cmd.Parameters.AddWithValue("@cor", a.Correo);
                    cmd.Parameters.AddWithValue("@nm", a.NombreMascota);
                    cmd.Parameters.AddWithValue("@tm", a.TipoMascota);
                    cmd.Parameters.AddWithValue("@em", a.EdadMascota);
                    cmd.Parameters.AddWithValue("@fa", a.FechaAtencion);
                    cmd.Parameters.AddWithValue("@ha", a.HoraAtencion);
                    cmd.Parameters.AddWithValue("@mc", a.MotivoConsulta);
                    cmd.Parameters.AddWithValue("@est", "Pendiente"); // Estado inicial por defecto

                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool ActualizarAgendamiento(Agendamiento a)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"UPDATE Agendamientos SET 
                                NombreDueno=@nd, Telefono=@tel, Correo=@cor, NombreMascota=@nm, 
                                TipoMascota=@tm, EdadMascota=@em, FechaAtencion=@fa, MotivoConsulta=@mc, Estado=@est 
                                WHERE IdAgendamiento = @id";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nd", a.NombreDueno);
                    cmd.Parameters.AddWithValue("@tel", a.Telefono);
                    cmd.Parameters.AddWithValue("@cor", a.Correo);
                    cmd.Parameters.AddWithValue("@nm", a.NombreMascota);
                    cmd.Parameters.AddWithValue("@tm", a.TipoMascota);
                    cmd.Parameters.AddWithValue("@em", a.EdadMascota);
                    cmd.Parameters.AddWithValue("@fa", a.FechaAtencion);
                    cmd.Parameters.AddWithValue("@mc", a.MotivoConsulta);
                    cmd.Parameters.AddWithValue("@est", a.Estado);
                    cmd.Parameters.AddWithValue("@id", a.IdAgendamiento);

                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool EliminarAgendamiento(int idAgendamiento)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "DELETE FROM Agendamientos WHERE IdAgendamiento = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idAgendamiento);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}

const mysql = require('mysql2');

// Conexion a MySQL
const conexion = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mvc'
});

conexion.connect((error) => {
    if (error) {
        console.log('Error de conexion a MySQL:', error);
        return;
    }

    console.log('Conexion exitosa a MySQL');
});

module.exports = conexion;

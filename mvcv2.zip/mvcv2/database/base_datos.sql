CREATE DATABASE IF NOT EXISTS mvc;
USE mvc;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    clave VARCHAR(100) NOT NULL
);

CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio INT NOT NULL,
    stock INT NOT NULL,
    usuario_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

INSERT INTO usuarios (nombre, correo, clave)
VALUES ('Administrador', 'admin@demo.cl', '1234');

INSERT INTO productos (nombre, precio, stock, usuario_id)
VALUES 
('Mouse', 10000, 15, 1),
('Teclado', 18000, 8, 1),
('Monitor', 120000, 5, 1);

# Proyecto básico MVC en Node.js con MySQL

Este proyecto está pensado para estudiantes que están comenzando con Node.js, Express, MySQL y MVC.

## Tecnologías usadas

- Node.js
- Express
- MySQL
- EJS
- express-session
- mysql2

## Estructura

```text
mvc-node-mysql-basico/
│
├── controllers/
│   ├── AuthController.js
│   └── ProductoController.js
│
├── database/
│   ├── base_datos.sql
│   └── conexion.js
│
├── models/
│   ├── UsuarioModel.js
│   └── ProductoModel.js
│
├── routes/
│   ├── authRoutes.js
│   └── productoRoutes.js
│
├── views/
│   ├── login.ejs
│   └── productos/
│       ├── listar.ejs
│       ├── crear.ejs
│       └── editar.ejs
│
├── public/
│   └── css/
│       └── estilos.css
│
├── server.js
└── package.json
```

## Relación entre tablas

El proyecto tiene dos tablas:

```text
usuarios
productos
```

La relación es:

```text
usuarios 1 -------- N productos
```

Un usuario puede registrar muchos productos.

## Paso 1: Crear la base de datos

Abrir phpMyAdmin o MySQL Workbench y ejecutar el archivo:

```text
database/base_datos.sql
```

Esto crea:

- Base de datos `mvc_basico`
- Tabla `usuarios`
- Tabla `productos`
- Usuario de prueba
- Productos de ejemplo

## Paso 2: Instalar dependencias

En la terminal, dentro de la carpeta del proyecto:

```bash
npm install
```

## Paso 3: Ejecutar el servidor

```bash
npm start
```

O en modo desarrollo:

```bash
npm run dev
```

## Paso 4: Abrir en el navegador

```text
http://localhost:3000
```

## Usuario de prueba

```text
Correo: admin@demo.cl
Clave: 1234
```

## Explicación MVC

### Modelo

El modelo se comunica con la base de datos.

Ejemplo:

```text
models/ProductoModel.js
```

### Vista

La vista muestra el HTML.

Ejemplo:

```text
views/productos/listar.ejs
```

### Controlador

El controlador recibe la petición, llama al modelo y responde con una vista.

Ejemplo:

```text
controllers/ProductoController.js
```

### Ruta

La ruta conecta una URL con un controlador.

Ejemplo:

```text
routes/productoRoutes.js
```

## Rutas principales

| Ruta | Acción |
|---|---|
| /login | Mostrar login |
| /login | Procesar login |
| /productos | Listar productos |
| /productos/crear | Crear producto |
| /productos/editar/:id | Editar producto |
| /productos/eliminar/:id | Eliminar producto |
| /logout | Cerrar sesión |

## Importante para clase

Este proyecto usa clave en texto simple para que sea fácil de entender en una primera clase.  
En un proyecto real, las claves deben ir encriptadas.

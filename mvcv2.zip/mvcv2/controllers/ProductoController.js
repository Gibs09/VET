const ProductoModel = require('../models/ProductoModel');

const ProductoController = {
    listar: (req, res) => {
        ProductoModel.listar((error, productos) => {
            if (error) {
                console.log(error);
                return res.send('Error al listar productos');
            }

            res.render('productos/listar', {
                productos: productos,
                usuario: req.session.usuario
            });
        });
    },

    mostrarCrear: (req, res) => {
        res.render('productos/crear');
    },

    guardar: (req, res) => {
        const nombre = req.body.nombre;
        const precio = req.body.precio;
        const stock = req.body.stock;
        const usuario_id = req.session.usuario.id;

        ProductoModel.crear(nombre, precio, stock, usuario_id, (error) => {
            if (error) {
                console.log(error);
                return res.send('Error al guardar producto');
            }

            res.redirect('/productos');
        });
    },

    mostrarEditar: (req, res) => {
        const id = req.params.id;

        ProductoModel.buscarPorId(id, (error, resultados) => {
            if (error) {
                console.log(error);
                return res.send('Error al buscar producto');
            }

            res.render('productos/editar', {
                producto: resultados[0]
            });
        });
    },

    actualizar: (req, res) => {
        const id = req.params.id;
        const nombre = req.body.nombre;
        const precio = req.body.precio;
        const stock = req.body.stock;

        ProductoModel.actualizar(id, nombre, precio, stock, (error) => {
            if (error) {
                console.log(error);
                return res.send('Error al actualizar producto');
            }

            res.redirect('/productos');
        });
    },

    eliminar: (req, res) => {
        const id = req.params.id;

        ProductoModel.eliminar(id, (error) => {
            if (error) {
                console.log(error);
                return res.send('Error al eliminar producto');
            }

            res.redirect('/productos');
        });
    }
};

module.exports = ProductoController;

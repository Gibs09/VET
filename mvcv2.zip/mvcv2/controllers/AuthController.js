const UsuarioModel = require('../models/UsuarioModel');

const AuthController = {
    mostrarLogin: (req, res) => {
        res.render('login', { error: null });
    },

    login: (req, res) => {
        const correo = req.body.correo;
        const clave = req.body.clave;

        UsuarioModel.buscarPorCorreoYClave(correo, clave, (error, resultados) => {
            if (error) {
                console.log(error);
                return res.send('Error al iniciar sesion');
            }

            if (resultados.length > 0) {
                req.session.usuario = resultados[0];
                return res.redirect('/productos');
            }

            res.render('login', { error: 'Correo o clave incorrectos' });
        });
    },

    logout: (req, res) => {
        req.session.destroy();
        res.redirect('/login');
    }
};

module.exports = AuthController;

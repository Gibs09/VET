const conexion = require('../database/conexion');

const UsuarioModel = {
    buscarPorCorreoYClave: (correo, clave, callback) => {
        const sql = 'SELECT * FROM usuarios WHERE correo = ? AND clave = ?';

        conexion.query(sql, [correo, clave], callback);
    }
};

module.exports = UsuarioModel;

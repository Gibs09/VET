const conexion = require('../database/conexion');

const ProductoModel = {
    listar: (callback) => {
        const sql = `
            SELECT productos.*, usuarios.nombre AS nombre_usuario
            FROM productos
            INNER JOIN usuarios ON productos.usuario_id = usuarios.id
        `;

        conexion.query(sql, callback);
    },

    crear: (nombre, precio, stock, usuario_id, callback) => {
        const sql = 'INSERT INTO productos (nombre, precio, stock, usuario_id) VALUES (?, ?, ?, ?)';

        conexion.query(sql, [nombre, precio, stock, usuario_id], callback);
    },

    buscarPorId: (id, callback) => {
        const sql = 'SELECT * FROM productos WHERE id = ?';

        conexion.query(sql, [id], callback);
    },

    actualizar: (id, nombre, precio, stock, callback) => {
        const sql = 'UPDATE productos SET nombre = ?, precio = ?, stock = ? WHERE id = ?';

        conexion.query(sql, [nombre, precio, stock, id], callback);
    },

    eliminar: (id, callback) => {
        const sql = 'DELETE FROM productos WHERE id = ?';

        conexion.query(sql, [id], callback);
    }
};

module.exports = ProductoModel;

const express = require('express');
const session = require('express-session');
const path = require('path');

const authRoutes = require('./routes/authRoutes');
const productoRoutes = require('./routes/productoRoutes');

const app = express();
const PORT = 3000;

// Configurar EJS como motor de vistas
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Archivos estaticos
app.use(express.static(path.join(__dirname, 'public')));

// Permite recibir datos desde formularios HTML
app.use(express.urlencoded({ extended: true }));

// Configuracion basica de sesion
app.use(session({
    secret: 'clave_basica',
    resave: false,
    saveUninitialized: false
}));

// Rutas
app.use('/', authRoutes);
app.use('/productos', productoRoutes);

// Ruta principal
app.get('/', (req, res) => {
    res.redirect('/login');
});

// Servidor
app.listen(PORT, () => {
    console.log('Servidor iniciado en http://localhost:' + PORT);
});

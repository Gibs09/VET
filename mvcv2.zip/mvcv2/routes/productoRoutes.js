const express = require('express');
const router = express.Router();

const ProductoController = require('../controllers/ProductoController');

// Middleware simple para proteger rutas
function protegerRuta(req, res, next) {
    if (req.session.usuario) {
        return next();
    }

    res.redirect('/login');
}

router.get('/', protegerRuta, ProductoController.listar);
router.get('/crear', protegerRuta, ProductoController.mostrarCrear);
router.post('/guardar', protegerRuta, ProductoController.guardar);
router.get('/editar/:id', protegerRuta, ProductoController.mostrarEditar);
router.post('/actualizar/:id', protegerRuta, ProductoController.actualizar);
router.get('/eliminar/:id', protegerRuta, ProductoController.eliminar);

module.exports = router;

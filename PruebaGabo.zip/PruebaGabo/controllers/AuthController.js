const ClienteModel = require('../models/ClienteModel');

const AuthController = {

    mostrarLogin: (req, res) => {
        res.render('login', { error: null });
    },

    login: (req, res) => {

        const { usuario, clave } = req.body;

        ClienteModel.login(usuario, clave, (err, results) => {

            if (err) {
                return res.render('login', {
                    error: 'Error del servidor'
                });
            }

            if (results.length > 0) {

                req.session.loggedin = true;
                req.session.usuario = usuario;

                res.redirect('/panel');

            } else {

                res.render('login', {
                    error: 'Credenciales incorrectas'
                });
            }
        });
    },

    logout: (req, res) => {

        req.session.destroy(() => {
            res.redirect('/login');
        });
    }
};

module.exports = AuthController;
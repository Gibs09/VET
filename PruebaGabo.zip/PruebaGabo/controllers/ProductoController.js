const ProductoModel = require('../models/ProductoModel');

const ProductoController = {

    mostrarProductos: (req, res) => {

        ProductoModel.obtenerProductos((err, results) => {

            if (err) {
                return res.send('Error al obtener productos');
            }

            res.render('index', {
                productos: results
            });
        });
    },

    mostrarPanel: (req, res) => {

        if (!req.session.loggedin) {
            return res.redirect('/login');
        }

        res.render('panel', {
            mensaje: null,
            error: null,
            usuario: req.session.usuario
        });
    },

    guardarProducto: (req, res) => {

        if (!req.session.loggedin) {
            return res.redirect('/login');
        }

        const datos = req.body;

        ProductoModel.agregarProducto(datos, (err) => {

            if (err) {
                return res.render('panel', {
                    mensaje: null,
                    error: 'Error al guardar producto',
                    usuario: req.session.usuario
                });
            }

            res.render('panel', {
                mensaje: 'Producto agregado correctamente',
                error: null,
                usuario: req.session.usuario
            });
        });
    }
};

module.exports = ProductoController;
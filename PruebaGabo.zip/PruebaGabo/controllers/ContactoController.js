const ContactoController = {

    mostrarContacto: (req, res) => {
        res.render('contacto', {
            mensaje: null
        });
    },

    enviarFormulario: (req, res) => {

        const { nombre, correo, mensaje } = req.body;

        if (!nombre || !correo || !mensaje) {
            return res.render('contacto', {
                mensaje: 'Todos los campos son obligatorios'
            });
        }

        res.render('contacto', {
            mensaje: 'Formulario enviado correctamente'
        });
    }
};

module.exports = ContactoController;
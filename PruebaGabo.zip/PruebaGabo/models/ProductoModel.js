const db = require('../config/database');

const ProductoModel = {

    obtenerProductos: (callback) => {
        const sql = 'SELECT * FROM productos';

        db.query(sql, callback);
    },

    agregarProducto: (datos, callback) => {
        const sql = `
        INSERT INTO productos
        (nombre, descripcion, url_imagen, precio)
        VALUES (?, ?, ?, ?)
        `;

        db.query(sql, [
            datos.nombre,
            datos.descripcion,
            datos.url_imagen,
            datos.precio
        ], callback);
    }
};

module.exports = ProductoModel;
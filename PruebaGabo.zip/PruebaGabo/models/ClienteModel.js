const db = require('../config/database');

const ClienteModel = {
    login: (usuario, clave, callback) => {
        const sql = 'SELECT * FROM clientes WHERE usuario = ? AND clave = ?';

        db.query(sql, [usuario, clave], callback);
    }
};

module.exports = ClienteModel;
const express = require('express');
const router = express.Router();

const ContactoController = require('../controllers/ContactoController');

router.get('/contacto', ContactoController.mostrarContacto);
router.post('/contacto', ContactoController.enviarFormulario);

module.exports = router;
const express = require('express');
const router = express.Router();

const ProductoController = require('../controllers/ProductoController');

router.get('/productos', ProductoController.mostrarProductos);
router.get('/panel', ProductoController.mostrarPanel);
router.post('/panel/agregar', ProductoController.guardarProducto);

module.exports = router;
const express = require('express');
const session = require('express-session');
const path = require('path');

const authRoutes = require('./routes/authRoutes');
const productoRoutes = require('./routes/productoRoutes');
const contactoRoutes = require('./routes/contactoRoutes');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(express.static(path.join(__dirname, 'assets')));

app.use(session({
    secret: 'secreto',
    resave: false,
    saveUninitialized: false
}));

// PRIMERA VISTA LOGIN
app.get('/', (req, res) => {
    res.redirect('/login');
});

app.use('/', authRoutes);
app.use('/', productoRoutes);
app.use('/', contactoRoutes);

app.listen(3000, () => {
    console.log('Servidor ejecutándose en puerto 3000');
});
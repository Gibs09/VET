﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using VetPatitasFelices.Data;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Controllers
{
    internal class AgendamientoController
    {
        private Conexion connx = new Conexion();

        public bool ExisteReserva(DateTime fecha, TimeSpan hora)
        {
            bool estaOcupado = false;
            try
            {
                using (SqlConnection con = connx.ObtenerConexion())
                {
                    string consulta = "SELECT COUNT(*) FROM Agendamientos WHERE FechaCita = @f AND HoraCita = @h";
                    SqlCommand cmd = new SqlCommand(consulta, con);
                    cmd.Parameters.AddWithValue("@f", fecha.Date);
                    cmd.Parameters.AddWithValue("@h", hora);

                    con.Open();
                    int coincidencias = (int)cmd.ExecuteScalar();

                    if (coincidencias > 0)
                    {
                        estaOcupado = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al verificar disponibilidad: " + ex.Message);
            }
            return estaOcupado;
        }

        
        public bool GuardarAgendamiento(Agendamiento nuevaCita)
        {
            try
            {
                
                if (ExisteReserva(nuevaCita.Fecha, nuevaCita.Hora))
                {
                    return false; 
                }

                using (SqlConnection con = connx.ObtenerConexion())
                {
                    string insert = @"INSERT INTO Agendamientos 
                                     (NombreMascota, Edad, NombreDueno, Telefono, CorreoContacto, FechaCita, HoraCita, MotivoConsulta) 
                                     VALUES (@mascota, @edad, @dueno, @fono, @mail, @fecha, @hora, @motivo)";

                    SqlCommand cmd = new SqlCommand(insert, con);
                    cmd.Parameters.AddWithValue("@nombredelamascota", nuevaCita.NombreDeLaMascota);
                    cmd.Parameters.AddWithValue("@edad", nuevaCita.Edad);
                    cmd.Parameters.AddWithValue("@nombre", nuevaCita.Nombre);
                    cmd.Parameters.AddWithValue("@fono", nuevaCita.Telefono);
                    cmd.Parameters.AddWithValue("@correo", nuevaCita.Correo);
                    cmd.Parameters.AddWithValue("@fecha", nuevaCita.Fecha);
                    cmd.Parameters.AddWithValue("@hora", nuevaCita.Hora);
                    cmd.Parameters.AddWithValue("@motivo", nuevaCita.Motivo);

                    con.Open();
                    int filas = cmd.ExecuteNonQuery();
                    return filas > 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Fallo al guardar en BD: " + ex.Message);
            }
        }

        
        public DataTable ObtenerTodasLasCitas()
        {
            DataTable tabla = new DataTable();
            try
            {
                using (SqlConnection con = connx.ObtenerConexion())
                {
                    string query = "SELECT * FROM Agendamientos ORDER BY FechaCita DESC, HoraCita DESC";
                    SqlDataAdapter adaptador = new SqlDataAdapter(query, con);
                    adaptador.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("No se pudieron cargar los datos: " + ex.Message);
            }
            return tabla;
        }
    }
}
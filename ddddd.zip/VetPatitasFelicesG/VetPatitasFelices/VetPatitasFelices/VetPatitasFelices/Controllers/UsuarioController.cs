﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using VetPatitasFelices.Data;
using VetPatitasFelices.Models;


using System.Data;




namespace VetPatitasFelices.Controllers
{
    internal class UsuarioController
    {
        private Conexion bd = new Conexion();

        // 1. El método que ya teníamos para iniciar sesión
        public Usuario IniciarSesion(string nombreUsuario, string claveUsuario)
        {
            Usuario usuarioEncontrado = null;
            try
            {
                using (SqlConnection conexion = bd.ObtenerConexion())
                {
                    string consulta = "SELECT Nombre, Rol FROM Usuarios WHERE Nombre = @nom AND Clave = @pass";
                    SqlCommand comando = new SqlCommand(consulta, conexion);
                    comando.Parameters.AddWithValue("@nom", nombreUsuario);
                    comando.Parameters.AddWithValue("@pass", claveUsuario);

                    conexion.Open();
                    SqlDataReader lector = comando.ExecuteReader();

                    if (lector.Read())
                    {
                        usuarioEncontrado = new Usuario();
                        usuarioEncontrado.Nombre = lector["Nombre"].ToString();
                        usuarioEncontrado.Clave = claveUsuario;
                        usuarioEncontrado.Rol = lector["Rol"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error en la base de datos: " + ex.Message);
            }
            return usuarioEncontrado;
        }

        // 2. NUEVO MÉTODO: Trae a las personas para mostrarlas en el FAdmin
        public DataTable ObtenerListaClientes()
        {
            DataTable tabla = new DataTable();
            try
            {
                using (SqlConnection conexion = bd.ObtenerConexion())
                {
                    // Solo traemos el Nombre y el Rol para que no se vea la clave
                    string consulta = "SELECT Nombre, Rol FROM Usuarios";
                    SqlDataAdapter adaptador = new SqlDataAdapter(consulta, conexion);

                    conexion.Open();
                    adaptador.Fill(tabla);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al cargar los datos: " + ex.Message);
            }
            return tabla;
        }
    }
}
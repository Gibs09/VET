﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices
{
    public partial class FCliente : Form
    {
        AgendamientoController citaController = new AgendamientoController();

        public FCliente()
        {
            InitializeComponent();
            CargarHorarios();
        }

        private void CargarHorarios()
        {
            cbHora.Items.Clear();
            for (int i = 9; i <= 18; i++)
            {
                cbHora.Items.Add($"{i:00}:00");
                cbHora.Items.Add($"{i:00}:30");
            }
            cbHora.SelectedIndex = 0;
        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNombreDeLaMascota.Text) ||
                    string.IsNullOrWhiteSpace(txtNombre.Text) ||
                    string.IsNullOrWhiteSpace(txtMotivo.Text))
                {
                    MessageBox.Show("No pueden haber campos de texto vacíos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                // Validacion Edad (Mayor a 0)
               
                if (!int.TryParse(txtEdad.Text, out int edadMascota) || edadMascota <= 0)
                {
                    MessageBox.Show("La edad debe ser un número entero mayor a 0.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                // Validacion Telefono (Solo Numero y Min 8 Max 12)
                
                string telefonoStr = txtTelefono.Text.Trim();
                if (!long.TryParse(telefonoStr, out _) || telefonoStr.Length < 8 || telefonoStr.Length > 12)
                {
                    MessageBox.Show("El teléfono debe contener solo números y tener entre 8 y 12 dígitos.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                // Validacion Correo
                
                string patronCorreo = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                if (!Regex.IsMatch(txtCorreo.Text.Trim(), patronCorreo))
                {
                    MessageBox.Show("El formato del correo electrónico no es válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                // Validacion Fecha 
                
                DateTime fechaSeleccionada = dtpFecha.Value.Date;
                if (fechaSeleccionada < DateTime.Now.Date)
                {
                    MessageBox.Show("No puedes agendar una reserva para una fecha pasada.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

               
                // Validacion Hora
                
                if (cbHora.SelectedItem == null || !TimeSpan.TryParse(cbHora.SelectedItem.ToString(), out TimeSpan horaSeleccionada))
                {
                    MessageBox.Show("Debe seleccionar una hora válida.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Fecha Hoy Hora no Pasada xd

                if (fechaSeleccionada == DateTime.Now.Date && horaSeleccionada <= DateTime.Now.TimeOfDay)
                {
                    MessageBox.Show("La hora seleccionada ya pasó el día de hoy.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                // Dupe Base de datos
                

                if (citaController.ExisteReserva(fechaSeleccionada, horaSeleccionada))
                {
                    MessageBox.Show("El horario seleccionado ya se encuentra ocupado. Por favor, elija otro.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                
                // Guardar Datos
                
                Agendamiento nuevaReserva = new Agendamiento
                {
                    NombreDeLaMascota = txtNombreDeLaMascota.Text.Trim(),
                    Edad = edadMascota,
                    Nombre = txtNombre.Text.Trim(),
                    Telefono = telefonoStr,
                    Correo = txtCorreo.Text.Trim(),
                    Fecha = fechaSeleccionada,
                    Hora = horaSeleccionada,
                    Motivo = txtMotivo.Text.Trim()
                };

                bool exito = citaController.GuardarAgendamiento(nuevaReserva);

                if (exito)
                {
                    MessageBox.Show("¡Reserva agendada exitosamente!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpiarFormulario();
                }
                else
                {
                    MessageBox.Show("No se pudo guardar la reserva en la base de datos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message, "Excepción", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarFormulario()
        {
            txtNombreDeLaMascota.Clear();
            txtEdad.Clear();
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtMotivo.Clear();
            dtpFecha.Value = DateTime.Now;
            cbHora.SelectedIndex = 0;
            txtNombreDeLaMascota.Focus();
        }
    }
}
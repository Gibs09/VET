﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Views
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        
        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            // Validacion básica de que no envíen el formulario en blanco
            if (string.IsNullOrWhiteSpace(txtUsuario.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Debes ingresar tu nombre y clave.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UsuarioController controlador = new UsuarioController();

            try
            {
                // Le pasamos los datos del TextBox al controlador
                Usuario user = controlador.IniciarSesion(txtUsuario.Text.Trim(), txtPass.Text.Trim());

                if (user != null)
                {
                    // Usamos la propiedad Nombre de tu modelo
                    MessageBox.Show("Bienvenido " + user.Nombre, "Ingreso Exitoso");

                    // Redirección según el rol
                    if (user.Rol == "Admin")
                    {
                        FAdmin ventanaAdmin = new FAdmin();
                        ventanaAdmin.Show();
                    }
                    else
                    {
                        FCliente ventanaCliente = new FCliente();
                        ventanaCliente.Show();
                    }

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Nombre o clave incorrectos.", "Error de Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPass.Clear();
                    txtUsuario.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error del sistema: " + ex.Message, "Error Crítico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;


using System;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;

namespace VetPatitasFelices.Views
{
    public partial class FAdmin : Form
    {
        // Instanciamos el controlador que ya usamos para el login
        private UsuarioController controlUsuarios = new UsuarioController();

        public FAdmin()
        {
            InitializeComponent();
        }

        // Este es el método que se conectó al hacer doble clic en el fondo
        private void FAdmin_Load(object sender, EventArgs e)
        {
            try
            {
                // Usamos el nombre real de tu grilla: dataGridView1
                dgvReservas.DataSource = controlUsuarios.ObtenerListaClientes();

                // Ajustamos las columnas para que se vea ordenado
                dgvReservas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los clientes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
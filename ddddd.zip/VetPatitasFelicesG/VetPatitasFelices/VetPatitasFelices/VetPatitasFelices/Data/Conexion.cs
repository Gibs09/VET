﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace VetPatitasFelices.Data
{
    internal class Conexion
    {
        // Cambiar Server=localhost; Database=VetPatitasFelices

        private string cadenaConexion = @"Server=(localdb)\MSSQLLocalDB;Database=VetPatitasFelicesDB;Integrated Security=True;";

        public SqlConnection ObtenerConexion()
        {
            try
            {
                SqlConnection conn = new SqlConnection(cadenaConexion);
                return conn;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la BD: " + ex.Message, "Error Critico", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}

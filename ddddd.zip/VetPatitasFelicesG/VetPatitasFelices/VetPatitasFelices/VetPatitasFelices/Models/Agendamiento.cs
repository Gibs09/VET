﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VetPatitasFelices.Models
{
    internal class Agendamiento
    {
        public int IdReserva { get; set; }
        public string NombreDeLaMascota { get; set; }
        public int Edad { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string TipoDeMascota { get; set; }
        public DateTime Fecha { get; set; }
        public TimeSpan Hora { get; set; }
        public string Motivo { get; set; }
        public string Estado { get; set; }
    }
}

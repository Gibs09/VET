﻿namespace VetPatitasFelices.Views
{
    partial class FAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblEdad = new System.Windows.Forms.Label();
            this.lblNombreDeLaMascota = new System.Windows.Forms.Label();
            this.lblTipoDeMascota = new System.Windows.Forms.Label();
            this.lblEditarEstado = new System.Windows.Forms.Label();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.lblFiltrarEstado = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.txtNombreDeLaMascota = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.cbEditarEstado = new System.Windows.Forms.ComboBox();
            this.cbFiltrarEstado = new System.Windows.Forms.ComboBox();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.cbTipoDeMascota = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(12, 366);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(62, 16);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombre :";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Location = new System.Drawing.Point(20, 448);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(54, 16);
            this.lblCorreo.TabIndex = 1;
            this.lblCorreo.Text = "Correo :";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(12, 409);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(67, 16);
            this.lblTelefono.TabIndex = 2;
            this.lblTelefono.Text = "Telefono :";
            // 
            // lblEdad
            // 
            this.lblEdad.AutoSize = true;
            this.lblEdad.Location = new System.Drawing.Point(279, 369);
            this.lblEdad.Name = "lblEdad";
            this.lblEdad.Size = new System.Drawing.Size(46, 16);
            this.lblEdad.TabIndex = 3;
            this.lblEdad.Text = "Edad :";
            // 
            // lblNombreDeLaMascota
            // 
            this.lblNombreDeLaMascota.AutoSize = true;
            this.lblNombreDeLaMascota.Location = new System.Drawing.Point(279, 406);
            this.lblNombreDeLaMascota.Name = "lblNombreDeLaMascota";
            this.lblNombreDeLaMascota.Size = new System.Drawing.Size(156, 16);
            this.lblNombreDeLaMascota.TabIndex = 4;
            this.lblNombreDeLaMascota.Text = "Nombre De La Mascota :";
            // 
            // lblTipoDeMascota
            // 
            this.lblTipoDeMascota.AutoSize = true;
            this.lblTipoDeMascota.Location = new System.Drawing.Point(279, 448);
            this.lblTipoDeMascota.Name = "lblTipoDeMascota";
            this.lblTipoDeMascota.Size = new System.Drawing.Size(117, 16);
            this.lblTipoDeMascota.TabIndex = 5;
            this.lblTipoDeMascota.Text = "Tipo De Mascota :";
            // 
            // lblEditarEstado
            // 
            this.lblEditarEstado.AutoSize = true;
            this.lblEditarEstado.Location = new System.Drawing.Point(735, 454);
            this.lblEditarEstado.Name = "lblEditarEstado";
            this.lblEditarEstado.Size = new System.Drawing.Size(94, 16);
            this.lblEditarEstado.TabIndex = 6;
            this.lblEditarEstado.Text = "Editar Estado :";
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Location = new System.Drawing.Point(595, 372);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(53, 16);
            this.lblMotivo.TabIndex = 7;
            this.lblMotivo.Text = "Motivo :";
            // 
            // lblFiltrarEstado
            // 
            this.lblFiltrarEstado.AutoSize = true;
            this.lblFiltrarEstado.Location = new System.Drawing.Point(735, 493);
            this.lblFiltrarEstado.Name = "lblFiltrarEstado";
            this.lblFiltrarEstado.Size = new System.Drawing.Size(92, 16);
            this.lblFiltrarEstado.TabIndex = 8;
            this.lblFiltrarEstado.Text = "Filtrar Estado :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(960, 335);
            this.dataGridView1.TabIndex = 9;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(80, 366);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(153, 22);
            this.txtNombre.TabIndex = 10;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(80, 406);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(153, 22);
            this.txtTelefono.TabIndex = 11;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(80, 442);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(153, 22);
            this.txtCorreo.TabIndex = 12;
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(331, 366);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(146, 22);
            this.txtEdad.TabIndex = 13;
            // 
            // txtNombreDeLaMascota
            // 
            this.txtNombreDeLaMascota.Location = new System.Drawing.Point(435, 403);
            this.txtNombreDeLaMascota.Name = "txtNombreDeLaMascota";
            this.txtNombreDeLaMascota.Size = new System.Drawing.Size(127, 22);
            this.txtNombreDeLaMascota.TabIndex = 14;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(15, 512);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 16;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(109, 512);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(75, 23);
            this.btnActualizar.TabIndex = 17;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(205, 512);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 18;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(738, 529);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(234, 22);
            this.dtpFecha.TabIndex = 19;
            this.dtpFecha.Value = new System.DateTime(2026, 4, 26, 0, 0, 0, 0);
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(654, 372);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(157, 22);
            this.txtMotivo.TabIndex = 20;
            // 
            // cbEditarEstado
            // 
            this.cbEditarEstado.FormattingEnabled = true;
            this.cbEditarEstado.Items.AddRange(new object[] {
            "Pendiente ",
            "Confirmada",
            "Atendida ",
            "Cancelada"});
            this.cbEditarEstado.Location = new System.Drawing.Point(834, 451);
            this.cbEditarEstado.Name = "cbEditarEstado";
            this.cbEditarEstado.Size = new System.Drawing.Size(138, 24);
            this.cbEditarEstado.TabIndex = 21;
            // 
            // cbFiltrarEstado
            // 
            this.cbFiltrarEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFiltrarEstado.FormattingEnabled = true;
            this.cbFiltrarEstado.Items.AddRange(new object[] {
            "Todas",
            "Pendiente ",
            "Confirmada",
            "Atendida ",
            "Cancelada"});
            this.cbFiltrarEstado.Location = new System.Drawing.Point(834, 484);
            this.cbFiltrarEstado.Name = "cbFiltrarEstado";
            this.cbFiltrarEstado.Size = new System.Drawing.Size(138, 24);
            this.cbFiltrarEstado.TabIndex = 22;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.Location = new System.Drawing.Point(302, 512);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(133, 23);
            this.btnCerrarSesion.TabIndex = 23;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            // 
            // cbTipoDeMascota
            // 
            this.cbTipoDeMascota.FormattingEnabled = true;
            this.cbTipoDeMascota.Items.AddRange(new object[] {
            "Perro ",
            "Gato",
            "Exótico",
            "Otro"});
            this.cbTipoDeMascota.Location = new System.Drawing.Point(403, 445);
            this.cbTipoDeMascota.Name = "cbTipoDeMascota";
            this.cbTipoDeMascota.Size = new System.Drawing.Size(159, 24);
            this.cbTipoDeMascota.TabIndex = 24;
            // 
            // FAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 563);
            this.Controls.Add(this.cbTipoDeMascota);
            this.Controls.Add(this.btnCerrarSesion);
            this.Controls.Add(this.cbFiltrarEstado);
            this.Controls.Add(this.cbEditarEstado);
            this.Controls.Add(this.txtMotivo);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.txtNombreDeLaMascota);
            this.Controls.Add(this.txtEdad);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblFiltrarEstado);
            this.Controls.Add(this.lblMotivo);
            this.Controls.Add(this.lblEditarEstado);
            this.Controls.Add(this.lblTipoDeMascota);
            this.Controls.Add(this.lblNombreDeLaMascota);
            this.Controls.Add(this.lblEdad);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.lblCorreo);
            this.Controls.Add(this.lblNombre);
            this.Name = "FAdmin";
            this.Text = "FAdmin";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblEdad;
        private System.Windows.Forms.Label lblNombreDeLaMascota;
        private System.Windows.Forms.Label lblTipoDeMascota;
        private System.Windows.Forms.Label lblEditarEstado;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.Label lblFiltrarEstado;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtEdad;
        private System.Windows.Forms.TextBox txtNombreDeLaMascota;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.ComboBox cbEditarEstado;
        private System.Windows.Forms.ComboBox cbFiltrarEstado;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.ComboBox cbTipoDeMascota;
    }
}
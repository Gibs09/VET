﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using VetPatitasFelices.Data;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Controllers
{
    public class ReservaController
    {
        private readonly Conexion conexion = new Conexion();

        public DataTable ObtenerReservas()
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "SELECT * FROM Agendamientos";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(tabla);
            }
            return tabla;
        }

        public DataTable FiltrarPorEstado(string estado)
        {
            if (estado == "General" || estado == "Todos") return ObtenerReservas();

            DataTable tabla = new DataTable();
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "SELECT * FROM Agendamientos WHERE Estado = @estado";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@estado", estado);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(tabla);
            }
            return tabla;
        }

        public bool RegistrarReserva(Reservas reserva)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"INSERT INTO Agendamientos
                    (NombreDueno, Telefono, Correo, NombreMascota, TipoMascota, EdadMascota, FechaAtencion, HoraAtencion, MotivoConsulta, Estado)
                    VALUES
                    (@nd, @tel, @cor, @nm, @tm, @em, @fa, @ha, @mc, @est)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nd", reserva.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", reserva.Telefono);
                cmd.Parameters.AddWithValue("@cor", reserva.Correo);
                cmd.Parameters.AddWithValue("@nm", reserva.NombreMascota);
                cmd.Parameters.AddWithValue("@tm", reserva.TipoMascota);
                cmd.Parameters.AddWithValue("@em", reserva.EdadMascota);
                cmd.Parameters.AddWithValue("@fa", reserva.FechaAtencion);
                cmd.Parameters.AddWithValue("@ha", reserva.HoraAtencion);
                cmd.Parameters.AddWithValue("@mc", reserva.MotivoConsulta);
                cmd.Parameters.AddWithValue("@est", reserva.Estado);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarEstado(int idAgendamiento, string estado)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "UPDATE Agendamientos SET Estado = @estado WHERE IdAgendamiento = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@estado", estado);
                cmd.Parameters.AddWithValue("@id", idAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarReserva(Reservas r)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"UPDATE Agendamientos SET
                    NombreDueno=@nd, Telefono=@tel, Correo=@cor,
                    NombreMascota=@nm, TipoMascota=@tm, EdadMascota=@em,
                    FechaAtencion=@fa, HoraAtencion=@ha, MotivoConsulta=@mc, Estado=@est
                    WHERE IdAgendamiento = @id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nd", r.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", r.Telefono);
                cmd.Parameters.AddWithValue("@cor", r.Correo);
                cmd.Parameters.AddWithValue("@nm", r.NombreMascota);
                cmd.Parameters.AddWithValue("@tm", r.TipoMascota);
                cmd.Parameters.AddWithValue("@em", r.EdadMascota);
                cmd.Parameters.AddWithValue("@fa", r.FechaAtencion);
                cmd.Parameters.AddWithValue("@ha", r.HoraAtencion);
                cmd.Parameters.AddWithValue("@mc", r.MotivoConsulta);
                cmd.Parameters.AddWithValue("@est", r.Estado);
                cmd.Parameters.AddWithValue("@id", r.IdAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool EliminarReserva(int idAgendamiento)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "DELETE FROM Agendamientos WHERE IdAgendamiento = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}

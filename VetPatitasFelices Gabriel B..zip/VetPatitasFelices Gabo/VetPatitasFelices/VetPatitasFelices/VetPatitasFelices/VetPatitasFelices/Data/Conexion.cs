﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace VetPatitasFelices.Data
{
    public class Conexion
    {
        // Asegúrate de que la cadena coincida con tu base de datos local

        private string cadenaConexion =
            "Server=(localdb)\\MSSQLLocalDB;Database=VetPet;Trusted_Connection=True;";

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}
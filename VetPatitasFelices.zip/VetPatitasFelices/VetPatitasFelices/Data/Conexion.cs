﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices;

namespace VetPatitasFelices.Data
{
    public class Conexion
    {
       
        private string cadenaConexion =
            "Server=(localdb)\\MSSQLLocalDB;Database=VetPet;Trusted_Connection=True;";

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}

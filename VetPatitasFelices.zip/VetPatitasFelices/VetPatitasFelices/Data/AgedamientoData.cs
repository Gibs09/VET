﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Data
{
    public class AgendamientoData
    {
        public List<Agendamiento> ObtenerAgendamientos(string filtroEstado = "")
        {
            List<Agendamiento> lista = new List<Agendamiento>();
            using (SqlConnection con = ConexionDB.GetConnection())
            {
                string query = "SELECT * FROM Agendamientos";
                if (!string.IsNullOrEmpty(filtroEstado) && filtroEstado != "Todos")
                {
                    query += " WHERE Estado = @estado";
                }

                SqlCommand cmd = new SqlCommand(query, con);
                if (!string.IsNullOrEmpty(filtroEstado) && filtroEstado != "Todos")
                {
                    cmd.Parameters.AddWithValue("@estado", filtroEstado);
                }

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Agendamiento()
                    {
                        IdAgendamiento = Convert.ToInt32(reader["IdAgendamiento"]),
                        NombreDueno = reader["NombreDueno"].ToString(),
                        Telefono = reader["Telefono"].ToString(),
                        Correo = reader["Correo"].ToString(),
                        NombreMascota = reader["NombreMascota"].ToString(),
                        TipoMascota = reader["TipoMascota"].ToString(),
                        EdadMascota = Convert.ToInt32(reader["EdadMascota"]),
                        FechaAtencion = Convert.ToDateTime(reader["FechaAtencion"]),
                        HoraAtencion = (TimeSpan)reader["HoraAtencion"],
                        MotivoConsulta = reader["MotivoConsulta"].ToString(),
                        Estado = reader["Estado"].ToString()
                    });
                }
            }
            return lista;
        }

        public bool Insertar(Agendamiento agen)
        {
            using (SqlConnection con = ConexionDB.GetConnection())
            {
                string query = "INSERT INTO Agendamientos (NombreDueno, Telefono, Correo, NombreMascota, TipoMascota, EdadMascota, FechaAtencion, HoraAtencion, MotivoConsulta, Estado) " +
                               "VALUES (@dueno, @tel, @correo, @mascota, @tipo, @edad, @fecha, @hora, @motivo, @estado)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dueno", agen.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", agen.Telefono);
                cmd.Parameters.AddWithValue("@correo", agen.Correo);
                cmd.Parameters.AddWithValue("@mascota", agen.NombreMascota);
                cmd.Parameters.AddWithValue("@tipo", agen.TipoMascota);
                cmd.Parameters.AddWithValue("@edad", agen.EdadMascota);
                cmd.Parameters.AddWithValue("@fecha", agen.FechaAtencion);
                cmd.Parameters.AddWithValue("@hora", agen.HoraAtencion);
                cmd.Parameters.AddWithValue("@motivo", agen.MotivoConsulta);
                cmd.Parameters.AddWithValue("@estado", agen.Estado); // Siempre 'Pendiente' en inserción

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Actualizar(Agendamiento agen)
        {
            using (SqlConnection con = ConexionDB.GetConnection())
            {
                string query = "UPDATE Agendamientos SET NombreDueno=@dueno, Telefono=@tel, Correo=@correo, NombreMascota=@mascota, TipoMascota=@tipo, EdadMascota=@edad, FechaAtencion=@fecha, HoraAtencion=@hora, MotivoConsulta=@motivo, Estado=@estado WHERE IdAgendamiento=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", agen.IdAgendamiento);
                cmd.Parameters.AddWithValue("@dueno", agen.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", agen.Telefono);
                cmd.Parameters.AddWithValue("@correo", agen.Correo);
                cmd.Parameters.AddWithValue("@mascota", agen.NombreMascota);
                cmd.Parameters.AddWithValue("@tipo", agen.TipoMascota);
                cmd.Parameters.AddWithValue("@edad", agen.EdadMascota);
                cmd.Parameters.AddWithValue("@fecha", agen.FechaAtencion);
                cmd.Parameters.AddWithValue("@hora", agen.HoraAtencion);
                cmd.Parameters.AddWithValue("@motivo", agen.MotivoConsulta);
                cmd.Parameters.AddWithValue("@estado", agen.Estado);

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Eliminar(int id)
        {
            using (SqlConnection con = ConexionDB.GetConnection())
            {
                string query = "DELETE FROM Agendamientos WHERE IdAgendamiento=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}

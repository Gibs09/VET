﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Data
{
    public class UsuarioData
    {
        public Usuario Autenticar(string username, string password)
        {
            Usuario usuario = null;
            using (SqlConnection con = ConexionDB.GetConnection())
            {
                string query = "SELECT IdUsuario, NombreUsuario, Rol FROM Usuarios WHERE NombreUsuario = @user AND Clave = @pass";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@user", username);
                cmd.Parameters.AddWithValue("@pass", password);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    usuario = new Usuario
                    {
                        IdUsuario = (int)reader["IdUsuario"],
                        NombreUsuario = reader["NombreUsuario"].ToString(),
                        Rol = reader["Rol"].ToString()
                    };
                }
            }
            return usuario;
        }
    }
}

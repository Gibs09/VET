﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VetPatitasFelices.Data
{
    public class ConexionDB
    {
        // Cambia el Data Source por el nombre de tu servidor SQL
        private static readonly string connectionString = "Server=(localdb)\\MSSQLLocalDB;Initial Catalog=VetPatitasFelices;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}

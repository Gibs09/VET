﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices.Data;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Controllers
{
    public class AgendamientoController
    {
        private AgendamientoData _agendamientoData = new AgendamientoData();

        public List<Agendamiento> Listar(string filtroEstado = "")
        {
            return _agendamientoData.ObtenerAgendamientos(filtroEstado);
        }

        public bool Registrar(Agendamiento agendamiento)
        {
            return _agendamientoData.Insertar(agendamiento);
        }

        public bool Actualizar(Agendamiento agendamiento)
        {
            return _agendamientoData.Actualizar(agendamiento);
        }

        public bool Eliminar(int id)
        {
            return _agendamientoData.Eliminar(id);
        }
    }
}

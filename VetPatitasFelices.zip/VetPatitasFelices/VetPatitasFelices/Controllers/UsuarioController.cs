﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VetPatitasFelices.Data;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Controllers
{
    public class UsuarioController
    {
        private UsuarioData _usuarioData = new UsuarioData();

        public Usuario Login(string user, string pass)
        {
            return _usuarioData.Autenticar(user, pass);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Views
{
    public partial class FCliente : Form
    {
        private TextBox txtDueno;
        private TextBox txtTelefono;
        private TextBox txtCorreo;
        private TextBox txtMascota;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox cbTipo;
        private TextBox txtEdad;
        private Label label5;
        private DateTimePicker dtpFecha;
        private TextBox txtHora;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtMotivo;
        private Label label9;
        private Button btnAgendar;
        private AgendamientoController _agenController = new AgendamientoController();

        public FCliente()
        {
            InitializeComponent();
        }

        private bool ValidarCampos()
        {
            // 1. Validar que ningún campo esté vacío
            if (string.IsNullOrWhiteSpace(txtDueno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtMascota.Text) ||
                string.IsNullOrWhiteSpace(txtEdad.Text) ||
                string.IsNullOrWhiteSpace(txtHora.Text) ||
                string.IsNullOrWhiteSpace(txtMotivo.Text) ||
                cbTipo.SelectedIndex == -1)
            {
                MessageBox.Show("Error: Faltan campos obligatorios. Por favor, complete todo el formulario.");
                return false;
            }

            // 2. Validar que la edad sea un número
            if (!int.TryParse(txtEdad.Text, out _))
            {
                MessageBox.Show("Error de formato: La edad de la mascota debe ser un número entero.");
                return false;
            }

            // 3. Validar que el teléfono solo contenga números
            if (!txtTelefono.Text.All(char.IsDigit))
            {
                MessageBox.Show("Error de formato: El teléfono solo debe contener números.");
                return false;
            }

            // 4. Validar formato de correo electrónico básico
            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Error de formato: Ingrese un correo electrónico válido.");
                return false;
            }

            // 5. Validar formato de la hora
            if (!TimeSpan.TryParse(txtHora.Text, out _))
            {
                MessageBox.Show("Error de formato: La hora debe tener el formato HH:MM (ejemplo: 14:30).");
                return false;
            }

            return true;
        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidarCampos()) return;

                Agendamiento agen = new Agendamiento()
                {
                    NombreDueno = txtDueno.Text,
                    Telefono = txtTelefono.Text,
                    Correo = txtCorreo.Text,
                    NombreMascota = txtMascota.Text,
                    TipoMascota = cbTipo.Text,
                    EdadMascota = int.Parse(txtEdad.Text),
                    FechaAtencion = dtpFecha.Value.Date,
                    HoraAtencion = TimeSpan.Parse(txtHora.Text),
                    MotivoConsulta = txtMotivo.Text,
                    Estado = "Pendiente" // Se fuerza el estado inicial a Pendiente según requerimiento
                };

                if (_agenController.Registrar(agen))
                {
                    MessageBox.Show("¡Reserva ingresada con éxito!");

                    // Limpieza de campos después de agendar
                    txtDueno.Clear();
                    txtTelefono.Clear();
                    txtCorreo.Clear();
                    txtMascota.Clear();
                    txtEdad.Clear();
                    txtHora.Clear();
                    txtMotivo.Clear();
                    cbTipo.SelectedIndex = -1;
                    dtpFecha.Value = DateTime.Now;
                }
                else
                {
                    MessageBox.Show("Error al agendar en la base de datos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error inesperado en el sistema.\n\nDetalle técnico: " + ex.Message);
            }
        }

        private void InitializeComponent()
        {
            this.txtDueno = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtMascota = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbTipo = new System.Windows.Forms.ComboBox();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAgendar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtDueno
            // 
            this.txtDueno.Location = new System.Drawing.Point(100, 40);
            this.txtDueno.Name = "txtDueno";
            this.txtDueno.Size = new System.Drawing.Size(162, 20);
            this.txtDueno.TabIndex = 0;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(408, 36);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(162, 20);
            this.txtTelefono.TabIndex = 1;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(100, 92);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(162, 20);
            this.txtCorreo.TabIndex = 2;
            // 
            // txtMascota
            // 
            this.txtMascota.Location = new System.Drawing.Point(100, 167);
            this.txtMascota.Name = "txtMascota";
            this.txtMascota.Size = new System.Drawing.Size(162, 20);
            this.txtMascota.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Dueño :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(322, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Telefono :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Correo :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Mascota :";
            // 
            // cbTipo
            // 
            this.cbTipo.FormattingEnabled = true;
            this.cbTipo.Items.AddRange(new object[] {
            "Perro",
            "Gato",
            "Exótico ",
            "Otro"});
            this.cbTipo.Location = new System.Drawing.Point(408, 167);
            this.cbTipo.Name = "cbTipo";
            this.cbTipo.Size = new System.Drawing.Size(162, 21);
            this.cbTipo.TabIndex = 8;
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(100, 213);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(162, 20);
            this.txtEdad.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Edad :";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(408, 257);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(90, 20);
            this.dtpFecha.TabIndex = 11;
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(408, 213);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(91, 20);
            this.txtHora.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(322, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Hora :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(322, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Fecha :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(322, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Tipo :";
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(100, 303);
            this.txtMotivo.Multiline = true;
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(162, 20);
            this.txtMotivo.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 310);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Motivo :";
            // 
            // btnAgendar
            // 
            this.btnAgendar.Location = new System.Drawing.Point(124, 394);
            this.btnAgendar.Name = "btnAgendar";
            this.btnAgendar.Size = new System.Drawing.Size(138, 23);
            this.btnAgendar.TabIndex = 18;
            this.btnAgendar.Text = "Agendar Reserva";
            this.btnAgendar.UseVisualStyleBackColor = true;
            this.btnAgendar.Click += new System.EventHandler(this.btnAgendar_Click);
            // 
            // FCliente
            // 
            this.ClientSize = new System.Drawing.Size(734, 467);
            this.Controls.Add(this.btnAgendar);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMotivo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtEdad);
            this.Controls.Add(this.cbTipo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMascota);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtDueno);
            this.Name = "FCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
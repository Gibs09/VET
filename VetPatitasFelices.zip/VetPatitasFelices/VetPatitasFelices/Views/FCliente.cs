﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices
{
    public partial class FCliente : Form
    {
        private Usuario usuarioActual;

        public FCliente(Usuario usuario = null)
        {
            InitializeComponent();
            usuarioActual = usuario;

            btnAgendarReserva.Click += BtnAgendarReserva_Click;
            lblCerrarSesion.Click += LblCerrarSesion_Click;
            this.FormClosing += FCliente_FormClosing;
        }

        private void BtnAgendarReserva_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtNombreDeLaMascota.Text) ||
                string.IsNullOrWhiteSpace(txtEdad.Text) ||
                string.IsNullOrWhiteSpace(cbTipoDeMascota.Text) ||
                string.IsNullOrWhiteSpace(cbHora.Text) ||
                string.IsNullOrWhiteSpace(txtMotivo.Text))
            {
                MessageBox.Show("Completa todos los campos.");
                return;
            }

            
            if (!Regex.IsMatch(txtNombre.Text, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
            {
                MessageBox.Show("El nombre del dueño solo debe contener letras.");
                return;
            }

            
            if (!Regex.IsMatch(txtTelefono.Text, @"^\d{9,12}$"))
            {
                MessageBox.Show("El teléfono debe contener solo números (9 a 12 dígitos).");
                return;
            }

            
            if (!int.TryParse(txtEdad.Text, out int edadMascotaValida))
            {
                MessageBox.Show("La edad debe ser un número válido.");
                return;
            }

            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Ingresa un correo electrónico válido.");
                return;
            }

            try
            {
                Reservas reserva = new Reservas
                {
                    NombreDueno = txtNombre.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim(),
                    Correo = txtCorreo.Text.Trim(),
                    NombreMascota = txtNombreDeLaMascota.Text.Trim(),
                    TipoMascota = cbTipoDeMascota.Text,
                    EdadMascota = edadMascotaValida,
                    FechaAtencion = dtpFecha.Value.Date,
                    HoraAtencion = cbHora.Text,
                    MotivoConsulta = txtMotivo.Text.Trim(),
                    Estado = "Pendiente"
                };

                ReservaController controller = new ReservaController();
                bool resultado = controller.RegistrarReserva(reserva);

                if (resultado)
                {
                    MessageBox.Show("Reserva registrada correctamente.");
                    LimpiarCampos();
                }
                else
                {
                    MessageBox.Show("No se pudo registrar la reserva.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtNombreDeLaMascota.Clear();
            txtEdad.Clear();
            cbTipoDeMascota.SelectedIndex = -1;
            dtpFecha.Value = DateTime.Now;
            cbHora.SelectedIndex = -1;
            txtMotivo.Clear();
        }

        private void LblCerrarSesion_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Application.OpenForms["FAdmin"] == null)
            {
                Application.Exit();
            }
        }
    }
}
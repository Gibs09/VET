﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;
using System.Text.RegularExpressions;

namespace VetPatitasFelices.Views
{
    public partial class FAdmin : Form
    {
        private Usuario usuarioActual;

        public FAdmin(Usuario usuario = null)
        {
            InitializeComponent();
            usuarioActual = usuario;
            CargarReservas();

            
            if (!cbFiltrarEstado.Items.Contains("Todos"))
            {
                cbFiltrarEstado.Items.Insert(0, "Todos");
            }

            btnAgregar.Click += BtnAgregar_Click;
            btnActualizar.Click += BtnActualizar_Click;
            btnEliminar.Click += BtnEliminar_Click;
            btnCerrarSesion.Click += BtnCerrarSesion_Click;
            dgvReserva.CellClick += DgvReserva_CellClick;
            cbFiltrarEstado.SelectedIndexChanged += CbFiltrarEstado_SelectedIndexChanged;
            this.FormClosing += FAdmin_FormClosing;
        }

        private void CargarReservas()
        {
            try
            {
                ReservaController controller = new ReservaController();
                dgvReserva.DataSource = controller.ObtenerReservas();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            FCliente clienteForm = new FCliente(usuarioActual);
            clienteForm.FormClosed += (s, args) => CargarReservas();
            clienteForm.ShowDialog();
        }

        private void DgvReserva_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvReserva.Rows[e.RowIndex];

                txtNombre.Text = fila.Cells["NombreDueno"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                txtCorreo.Text = fila.Cells["Correo"].Value.ToString();
                txtEdad.Text = fila.Cells["EdadMascota"].Value.ToString();
                txtNombreDeLaMascota.Text = fila.Cells["NombreMascota"].Value.ToString();
                cbTipoDeMascota.Text = fila.Cells["TipoMascota"].Value.ToString();
                txtMotivo.Text = fila.Cells["MotivoConsulta"].Value.ToString();
                cbEditarEstado.Text = fila.Cells["Estado"].Value.ToString();

                if (DateTime.TryParse(fila.Cells["FechaAtencion"].Value.ToString(), out DateTime fecha))
                {
                    dtpFecha.Value = fecha;
                }
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvReserva.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una reserva de la tabla.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtNombreDeLaMascota.Text) ||
                string.IsNullOrWhiteSpace(txtEdad.Text) ||
                string.IsNullOrWhiteSpace(cbTipoDeMascota.Text) ||
                string.IsNullOrWhiteSpace(txtMotivo.Text) ||
                string.IsNullOrWhiteSpace(cbEditarEstado.Text))
            {
                MessageBox.Show("Completa todos los campos para actualizar.");
                return;
            }

            if (!Regex.IsMatch(txtNombre.Text, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
            {
                MessageBox.Show("El nombre del dueño solo debe contener letras.");
                return;
            }

            if (!Regex.IsMatch(txtNombreDeLaMascota.Text, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
            {
                MessageBox.Show("El nombre de la mascota solo debe contener letras.");
                return;
            }

            if (!Regex.IsMatch(txtTelefono.Text, @"^\d{9,12}$"))
            {
                MessageBox.Show("El teléfono debe contener solo números (9 a 12 dígitos).");
                return;
            }

            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Ingresa un correo electrónico válido.");
                return;
            }

            if (!int.TryParse(txtEdad.Text, out int edadMascotaValida))
            {
                MessageBox.Show("La edad debe ser un número válido.");
                return;
            }

            try
            {
                int idSeleccionado = Convert.ToInt32(dgvReserva.CurrentRow.Cells["IdAgendamiento"].Value);
                string horaOriginal = dgvReserva.CurrentRow.Cells["HoraAtencion"].Value.ToString();

                Reservas reservaModificada = new Reservas
                {
                    IdAgendamiento = idSeleccionado,
                    NombreDueno = txtNombre.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim(),
                    Correo = txtCorreo.Text.Trim(),
                    NombreMascota = txtNombreDeLaMascota.Text.Trim(),
                    TipoMascota = cbTipoDeMascota.Text,
                    EdadMascota = edadMascotaValida,
                    FechaAtencion = dtpFecha.Value.Date,
                    HoraAtencion = horaOriginal,
                    MotivoConsulta = txtMotivo.Text.Trim(),
                    Estado = cbEditarEstado.Text
                };

                ReservaController controller = new ReservaController();

                if (controller.ActualizarReserva(reservaModificada))
                {
                    MessageBox.Show("Reserva actualizada correctamente.");
                    CargarReservas();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar la reserva.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvReserva.CurrentRow == null) return;

            DialogResult confirm = MessageBox.Show("¿Eliminar reserva?", "Confirmar", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                int id = Convert.ToInt32(dgvReserva.CurrentRow.Cells["IdAgendamiento"].Value);
                ReservaController controller = new ReservaController();
                if (controller.EliminarReserva(id))
                {
                    CargarReservas();
                }
            }
        }

        private void CbFiltrarEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cbFiltrarEstado.Text)) return;

            ReservaController controller = new ReservaController();

            
            if (cbFiltrarEstado.Text == "Todos")
            {
                dgvReserva.DataSource = controller.ObtenerReservas();
            }
            else
            {
                dgvReserva.DataSource = controller.FiltrarPorEstado(cbFiltrarEstado.Text);
            }
        }

        private void BtnCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
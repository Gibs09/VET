﻿using System;
using System.Linq;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Views
{
    public partial class FAdmin : Form
    {
        private ComboBox cbFiltroEstado;
        private DataGridView dgvAgendamientos;
        private TextBox txtTipo;
        private ComboBox cbEstadoEdit;

        private Button btnAgregar;
        private Button btnActualizarEstado;
        private Button btnEliminar;

        private TextBox txtDueño;
        private TextBox txtTelefono;
        private TextBox txtCorreo;
        private TextBox txtMascota;
        private TextBox txtEdad;
        private DateTimePicker dtpFecha;
        private TextBox txtHora;
        private TextBox txtMotivo;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private AgendamientoController _agenController = new AgendamientoController();

        public FAdmin()
        {
            InitializeComponent();

            cbFiltroEstado.Items.AddRange(new string[] { "Todos", "Pendiente", "Confirmada", "Atendida", "Cancelada" });
            cbFiltroEstado.SelectedIndex = 0;

            cbEstadoEdit.Items.AddRange(new string[] { "Pendiente", "Confirmada", "Atendida", "Cancelada" });
            CargarGrilla();
        }

        private void CargarGrilla(string filtro = "")
        {
            dgvAgendamientos.DataSource = _agenController.Listar(filtro);
        }

        private void dgvAgendamientos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificamos que se haya hecho clic en una fila válida (no en el encabezado)
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvAgendamientos.Rows[e.RowIndex];

                // Extraemos y asignamos los datos a los controles
                txtDueño.Text = fila.Cells["NombreDueno"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                txtCorreo.Text = fila.Cells["Correo"].Value.ToString();
                txtMascota.Text = fila.Cells["NombreMascota"].Value.ToString();
                txtTipo.Text = fila.Cells["TipoMascota"].Value.ToString();
                txtEdad.Text = fila.Cells["EdadMascota"].Value.ToString();
                dtpFecha.Value = Convert.ToDateTime(fila.Cells["FechaAtencion"].Value);
                txtHora.Text = fila.Cells["HoraAtencion"].Value.ToString();
                txtMotivo.Text = fila.Cells["MotivoConsulta"].Value.ToString();
                cbEstadoEdit.Text = fila.Cells["Estado"].Value.ToString();
            }
        }

        private void cbFiltroEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargarGrilla(cbFiltroEstado.SelectedItem.ToString());
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            FCliente formAgendar = new FCliente();
            formAgendar.ShowDialog();
            CargarGrilla();
        }

        // --- MÉTODO DE VALIDACIÓN AGREGADO AQUÍ ---
        private bool ValidarCamposEdicion()
        {
            // 1. Validar que ningún campo esté vacío
            if (string.IsNullOrWhiteSpace(txtDueño.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtMascota.Text) ||
                string.IsNullOrWhiteSpace(txtEdad.Text) ||
                string.IsNullOrWhiteSpace(txtHora.Text) ||
                string.IsNullOrWhiteSpace(txtMotivo.Text) ||
                string.IsNullOrWhiteSpace(txtTipo.Text) ||
                string.IsNullOrWhiteSpace(cbEstadoEdit.Text))
            {
                MessageBox.Show("Error: Faltan campos obligatorios. Por favor, seleccione un registro y complete todos los datos antes de actualizar.");
                return false;
            }

            // 2. Validar que la edad sea un número
            if (!int.TryParse(txtEdad.Text, out _))
            {
                MessageBox.Show("Error de formato: La edad de la mascota debe ser un número entero.");
                return false;
            }

            // 3. Validar que el teléfono solo contenga números
            if (!txtTelefono.Text.All(char.IsDigit))
            {
                MessageBox.Show("Error de formato: El teléfono solo debe contener números.");
                return false;
            }

            // 4. Validar formato de correo electrónico básico
            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Error de formato: Ingrese un correo electrónico válido.");
                return false;
            }

            // 5. Validar formato de la hora
            if (!TimeSpan.TryParse(txtHora.Text, out _))
            {
                MessageBox.Show("Error de formato: La hora debe tener el formato HH:MM (ejemplo: 14:30).");
                return false;
            }

            return true;
        }

        // --- BOTÓN ACTUALIZAR MODIFICADO AQUÍ ---
        private void btnActualizarEstado_Click(object sender, EventArgs e)
        {
            if (dgvAgendamientos.SelectedRows.Count > 0)
            {
                // Llamamos a la validación antes de continuar
                if (!ValidarCamposEdicion()) return;

                int id = Convert.ToInt32(dgvAgendamientos.CurrentRow.Cells["IdAgendamiento"].Value);

                try
                {
                    Agendamiento agen = new Agendamiento()
                    {
                        IdAgendamiento = id,
                        NombreDueno = txtDueño.Text,
                        Telefono = txtTelefono.Text,
                        Correo = txtCorreo.Text,
                        NombreMascota = txtMascota.Text,
                        TipoMascota = txtTipo.Text,
                        EdadMascota = int.Parse(txtEdad.Text),
                        FechaAtencion = dtpFecha.Value.Date,
                        HoraAtencion = TimeSpan.Parse(txtHora.Text),
                        MotivoConsulta = txtMotivo.Text,
                        Estado = cbEstadoEdit.Text
                    };

                    if (_agenController.Actualizar(agen))
                    {
                        MessageBox.Show("Agendamiento actualizado correctamente.");
                        CargarGrilla();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error de base de datos al actualizar el registro:\n" + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un registro de la grilla para actualizar.");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvAgendamientos.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvAgendamientos.CurrentRow.Cells["IdAgendamiento"].Value);
                if (_agenController.Eliminar(id))
                {
                    MessageBox.Show("Agendamiento eliminado.");
                    CargarGrilla();
                }
            }
        }

        private void InitializeComponent()
        {
            this.cbFiltroEstado = new System.Windows.Forms.ComboBox();
            this.dgvAgendamientos = new System.Windows.Forms.DataGridView();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.cbEstadoEdit = new System.Windows.Forms.ComboBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnActualizarEstado = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txtDueño = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtMascota = new System.Windows.Forms.TextBox();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamientos)).BeginInit();
            this.SuspendLayout();
            // 
            // cbFiltroEstado
            // 
            this.cbFiltroEstado.Location = new System.Drawing.Point(617, 622);
            this.cbFiltroEstado.Name = "cbFiltroEstado";
            this.cbFiltroEstado.Size = new System.Drawing.Size(121, 21);
            this.cbFiltroEstado.TabIndex = 1;
            this.cbFiltroEstado.SelectedIndexChanged += new System.EventHandler(this.cbFiltroEstado_SelectedIndexChanged);
            // 
            // dgvAgendamientos
            // 
            this.dgvAgendamientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgendamientos.Location = new System.Drawing.Point(12, 12);
            this.dgvAgendamientos.Name = "dgvAgendamientos";
            this.dgvAgendamientos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAgendamientos.Size = new System.Drawing.Size(902, 323);
            this.dgvAgendamientos.TabIndex = 0;
            this.dgvAgendamientos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgendamientos_CellClick);
            // 
            // txtTipo
            // 
            this.txtTipo.Location = new System.Drawing.Point(732, 388);
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(118, 20);
            this.txtTipo.TabIndex = 13;
            // 
            // cbEstadoEdit
            // 
            this.cbEstadoEdit.Location = new System.Drawing.Point(757, 425);
            this.cbEstadoEdit.Name = "cbEstadoEdit";
            this.cbEstadoEdit.Size = new System.Drawing.Size(121, 21);
            this.cbEstadoEdit.TabIndex = 14;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(12, 612);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 2;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnActualizarEstado
            // 
            this.btnActualizarEstado.Location = new System.Drawing.Point(93, 612);
            this.btnActualizarEstado.Name = "btnActualizarEstado";
            this.btnActualizarEstado.Size = new System.Drawing.Size(75, 23);
            this.btnActualizarEstado.TabIndex = 3;
            this.btnActualizarEstado.Text = "Actualizar";
            this.btnActualizarEstado.Click += new System.EventHandler(this.btnActualizarEstado_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(174, 612);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 4;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // txtDueño
            // 
            this.txtDueño.Location = new System.Drawing.Point(59, 382);
            this.txtDueño.Name = "txtDueño";
            this.txtDueño.Size = new System.Drawing.Size(122, 20);
            this.txtDueño.TabIndex = 5;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(282, 385);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(120, 20);
            this.txtTelefono.TabIndex = 6;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(59, 427);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(122, 20);
            this.txtCorreo.TabIndex = 7;
            // 
            // txtMascota
            // 
            this.txtMascota.Location = new System.Drawing.Point(510, 385);
            this.txtMascota.Name = "txtMascota";
            this.txtMascota.Size = new System.Drawing.Size(116, 20);
            this.txtMascota.TabIndex = 8;
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(510, 426);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(116, 20);
            this.txtEdad.TabIndex = 9;
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(617, 547);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(200, 20);
            this.dtpFecha.TabIndex = 10;
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(282, 426);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(120, 20);
            this.txtHora.TabIndex = 11;
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(732, 478);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(133, 20);
            this.txtMotivo.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(475, 622);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Filtrar Estado :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 430);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Correo :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 385);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Dueño :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(212, 385);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Telefono :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 430);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Hora :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(444, 388);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Mascota :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(444, 433);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Edad :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(677, 388);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Tipo :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(662, 429);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Editar Estado :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(666, 481);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Motivo :";
            // 
            // FAdmin
            // 
            this.ClientSize = new System.Drawing.Size(926, 720);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvAgendamientos);
            this.Controls.Add(this.cbFiltroEstado);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnActualizarEstado);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.txtDueño);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtMascota);
            this.Controls.Add(this.txtEdad);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.txtMotivo);
            this.Controls.Add(this.txtTipo);
            this.Controls.Add(this.cbEstadoEdit);
            this.Name = "FAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamientos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
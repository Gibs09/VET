﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;


namespace VetPatitasFelices.Views
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            
            btnIniciarSesion.Click += BtnIniciarSesion_Click;
        }

        private void BtnIniciarSesion_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsuario.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Ingresa usuario y contraseña.");
                return;
            }

            UsuarioController control = new UsuarioController();
            string usuario = txtUsuario.Text.Trim();
            string clave = txtPass.Text.Trim();

            Usuario usuarioLogueado = control.ValidarUsuario(usuario, clave);

            if (usuarioLogueado != null)
            {
                MessageBox.Show("Bienvenido " + usuarioLogueado.NombreUsuario);

                if (usuarioLogueado.Rol == "Administrador")
                {
                    FAdmin admin = new FAdmin(usuarioLogueado);
                    admin.Show();
                }
                else if (usuarioLogueado.Rol == "Cliente")
                {
                    FCliente cliente = new FCliente(usuarioLogueado);
                    cliente.Show();
                }

                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
    }
}
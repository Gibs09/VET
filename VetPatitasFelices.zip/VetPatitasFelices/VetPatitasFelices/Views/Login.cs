﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VetPatitasFelices.Controllers;
using VetPatitasFelices.Models;

namespace VetPatitasFelices.Views
{
    public partial class Login : Form
    {
        private Label lblTitulo;
        private Label lblUser;
        private Label lblPass;
        private TextBox txtUser;
        private TextBox txtPass;
        private Button btnLogin;
        private UsuarioController _userController = new UsuarioController();

        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtUser.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
                {
                    MessageBox.Show("Ingrese usuario y contraseña.");
                    return;
                }

                Usuario user = _userController.Login(txtUser.Text, txtPass.Text);

                if (user != null)
                {
                    this.Hide();
                    if (user.Rol == "Administrador")
                    {
                        FAdmin formAdmin = new FAdmin();
                        formAdmin.ShowDialog();
                    }
                    else
                    {
                        FCliente formCliente = new FCliente();
                        formCliente.ShowDialog();
                    }
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Credenciales incorrectas");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexión a la base de datos: " + ex.Message);
            }
        }

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.lblPass = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(156, 59);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(163, 13);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Veterinaria Patitas Felices - Login";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(112, 146);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(49, 13);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Usuario :";
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Location = new System.Drawing.Point(100, 188);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(70, 13);
            this.lblPass.TabIndex = 2;
            this.lblPass.Text = "Contraseña : ";
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(207, 143);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(134, 20);
            this.txtUser.TabIndex = 3;
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(207, 188);
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*'; // Agregado para ocultar la contraseña
            this.txtPass.Size = new System.Drawing.Size(134, 20);
            this.txtPass.TabIndex = 4;
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(193, 274);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "Ingresar";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click); // CONEXIÓN DEL EVENTO
            // 
            // Login
            // 
            this.ClientSize = new System.Drawing.Size(460, 380); // Ajusté un poco el tamaño para que no quede tan vacío
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.lblPass);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen; // Para que abra centrado
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
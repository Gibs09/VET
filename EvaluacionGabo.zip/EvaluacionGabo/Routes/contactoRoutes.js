const express = require('express');
const router = express.Router();

const ContactoController = require('../Controllers/ContactoController');

router.get('/contacto', ContactoController.contacto);
router.post('/contacto', ContactoController.enviarContacto);

module.exports = router;
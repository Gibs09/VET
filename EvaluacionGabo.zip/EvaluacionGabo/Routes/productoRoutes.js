const express = require('express');
const router = express.Router();

const ProductoController = require('../Controllers/ProductoController');

router.get('/', ProductoController.inicio);
router.get('/panel', ProductoController.panel);
router.get('/crear-producto', ProductoController.crearProducto);
router.post('/guardar-producto', ProductoController.guardarProducto);
router.get('/editar-producto/:id', ProductoController.editarProducto);
router.post('/actualizar-producto/:id', ProductoController.actualizarProducto);
router.get('/eliminar-producto/:id', ProductoController.eliminarProducto);

module.exports = router;
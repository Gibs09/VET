const conexion = require('../Config/database');

exports.inicio = (req, res) => {

    const sql = 'SELECT * FROM productos';

    conexion.query(sql, (error, resultados) => {

        if(error){

            console.log(error);

        }

        res.render('index', {

            productos: resultados

        });

    });

};

exports.panel = (req, res) => {

    if(!req.session.usuario){

        return res.redirect('/login');

    }

    const sql = 'SELECT * FROM productos';

    conexion.query(sql, (error, resultados) => {

        if(error){

            console.log(error);

        }

        res.render('panel', {

            productos: resultados

        });

    });

};

exports.crearProducto = (req, res) => {

    if(!req.session.usuario){

        return res.redirect('/login');

    }

    res.render('crearProducto', {

        mensaje: null

    });

};

exports.guardarProducto = (req, res) => {

    const { nombre, descripcion, imagen_url, precio } = req.body;

    if(!nombre || !descripcion || !imagen_url || !precio){

        return res.render('crearProducto', {

            mensaje: 'Todos los campos son obligatorios'

        });

    }

    if(precio <= 0){

        return res.render('crearProducto', {

            mensaje: 'Precio inválido'

        });

    }

    const sql = `
    INSERT INTO productos(nombre, descripcion, imagen_url, precio)
    VALUES (?, ?, ?, ?)
    `;

    conexion.query(

        sql,

        [nombre, descripcion, imagen_url, precio],

        (error) => {

            if(error){

                console.log(error);

                return res.render('crearProducto', {

                    mensaje: 'Error al guardar producto'

                });

            }

            res.redirect('/panel');

        }
    );

};

exports.editarProducto = (req, res) => {

    const id = req.params.id;

    const sql = 'SELECT * FROM productos WHERE id = ?';

    conexion.query(sql, [id], (error, resultados) => {

        if(error){

            console.log(error);

        }

        res.render('editarProducto', {

            producto: resultados[0]

        });

    });

};

exports.actualizarProducto = (req, res) => {

    const id = req.params.id;

    const { nombre, descripcion, imagen_url, precio } = req.body;

    const sql = `
    UPDATE productos
    SET nombre=?, descripcion=?, imagen_url=?, precio=?
    WHERE id=?
    `;

    conexion.query(

        sql,

        [nombre, descripcion, imagen_url, precio, id],

        (error) => {

            if(error){

                console.log(error);

            }

            res.redirect('/panel');

        }
    );

};

exports.eliminarProducto = (req, res) => {

    const id = req.params.id;

    const sql = 'DELETE FROM productos WHERE id=?';

    conexion.query(sql, [id], (error) => {

        if(error){

            console.log(error);

        }

        res.redirect('/panel');

    });

};
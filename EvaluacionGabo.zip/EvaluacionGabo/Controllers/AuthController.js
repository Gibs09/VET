const conexion = require('../Config/database');

exports.mostrarLogin = (req, res) => {

    res.render('login', {

        mensaje: null

    });

};

exports.login = (req, res) => {

    const { usuario, clave } = req.body;

    if(!usuario || !clave){

        return res.render('login', {

            mensaje: 'Todos los campos son obligatorios'

        });

    }

    const sql = `
    SELECT * FROM clientes 
    WHERE usuario = ? AND clave = ?
    `;

    conexion.query(sql, [usuario, clave], (error, resultados) => {

        if(error){

            console.log(error);

            return res.render('login', {

                mensaje: 'Error del sistema'

            });

        }

        if(resultados.length > 0){

            req.session.usuario = resultados[0];

            res.redirect('/panel');

        } else {

            res.render('login', {

                mensaje: 'Usuario o contraseña incorrecta'

            });

        }

    });

};

exports.logout = (req, res) => {

    req.session.destroy(() => {

        res.redirect('/login');

    });

};
exports.contacto = (req, res) => {

    res.render('contacto', {
        mensaje: null
    });
};

exports.enviarContacto = (req, res) => {

    const { nombre, correo, mensaje } = req.body;

    if(!nombre || !correo || !mensaje){

        return res.render('contacto', {
            mensaje: 'Todos los campos son obligatorios'
        });
    }

    if(!correo.includes('@')){

        return res.render('contacto', {
            mensaje: 'Correo inválido'
        });
    }

    res.render('contacto', {
        mensaje: 'Mensaje enviado correctamente'
    });
};
const express = require('express');

const session = require('express-session');

const path = require('path');

const ejs = require('ejs');

const productoRoutes = require('./Routes/productoRoutes');

const authRoutes = require('./Routes/authRoutes');

const app = express();

app.use(express.urlencoded({ extended: true }));

app.use(express.json());

app.use(session({

    secret: 'tienda_virtual',

    resave: false,

    saveUninitialized: false

}));

app.engine('html', ejs.renderFile);

app.set('view engine', 'html');

app.set('views', path.join(__dirname, 'Views'));

app.use('/Assets', express.static(path.join(__dirname, 'Assets')));

app.use('/', productoRoutes);

app.use('/', authRoutes);

const PORT = 3000;

app.listen(PORT, () => {

    console.log('Servidor funcionando en puerto 3000');

});
﻿using PatitasFelicesApp.Datos;
using PatitasFelicesApp.Modelos;
using System;
using System.Data;
using System.Data.SqlClient;

namespace PatitasFelicesApp.Controladores
{
    public class AgendamientoController
    {
        private readonly Conexion conexion = new Conexion();

        public DataTable ObtenerAgendamientos()
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "SELECT * FROM Agendamientos";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(tabla);
            }
            return tabla;
        }

        public DataTable FiltrarPorEstado(string estado)
        {
            if (estado == "General") return ObtenerAgendamientos();

            DataTable tabla = new DataTable();
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "SELECT * FROM Agendamientos WHERE Estado = @estado";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@estado", estado);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(tabla);
            }
            return tabla;
        }

        public bool RegistrarAgendamiento(Agendamiento agendamiento)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"INSERT INTO Agendamientos
                    (NombreDueno, Telefono, Correo, NombreMascota, TipoMascota, EdadMascota, FechaAtencion, HoraAtencion, MotivoConsulta, Estado)
                    VALUES
                    (@nombreDueno, @telefono, @correo, @nombreMascota, @tipoMascota, @edadMascota, @fecha, @hora, @motivo, @estado)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nombreDueno", agendamiento.NombreDueno);
                cmd.Parameters.AddWithValue("@telefono", agendamiento.Telefono);
                cmd.Parameters.AddWithValue("@correo", agendamiento.Correo);
                cmd.Parameters.AddWithValue("@nombreMascota", agendamiento.NombreMascota);
                cmd.Parameters.AddWithValue("@tipoMascota", agendamiento.TipoMascota);
                cmd.Parameters.AddWithValue("@edadMascota", agendamiento.EdadMascota);
                cmd.Parameters.AddWithValue("@fecha", agendamiento.FechaAtencion);
                cmd.Parameters.AddWithValue("@hora", agendamiento.HoraAtencion);
                cmd.Parameters.AddWithValue("@motivo", agendamiento.MotivoConsulta);
                cmd.Parameters.AddWithValue("@estado", agendamiento.Estado);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarAgendamiento(Agendamiento a)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = @"UPDATE Agendamientos SET
                    NombreDueno=@nd, Telefono=@tel, Correo=@cor,
                    NombreMascota=@nm, TipoMascota=@tm, EdadMascota=@em,
                    FechaAtencion=@fa, HoraAtencion=@ha, MotivoConsulta=@mc, Estado=@est
                    WHERE IdAgendamiento = @id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nd", a.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", a.Telefono);
                cmd.Parameters.AddWithValue("@cor", a.Correo);
                cmd.Parameters.AddWithValue("@nm", a.NombreMascota);
                cmd.Parameters.AddWithValue("@tm", a.TipoMascota);
                cmd.Parameters.AddWithValue("@em", a.EdadMascota);
                cmd.Parameters.AddWithValue("@fa", a.FechaAtencion);
                cmd.Parameters.AddWithValue("@ha", a.HoraAtencion);
                cmd.Parameters.AddWithValue("@mc", a.MotivoConsulta);
                cmd.Parameters.AddWithValue("@est", a.Estado);
                cmd.Parameters.AddWithValue("@id", a.IdAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarEstado(int idAgendamiento, string estado)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "UPDATE Agendamientos SET Estado = @estado WHERE IdAgendamiento = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@estado", estado);
                cmd.Parameters.AddWithValue("@id", idAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool EliminarAgendamiento(int idAgendamiento)
        {
            using (SqlConnection conn = conexion.ObtenerConexion())
            {
                conn.Open();
                string query = "DELETE FROM Agendamientos WHERE IdAgendamiento = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", idAgendamiento);
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}
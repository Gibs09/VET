﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatitasFelicesApp.Datos
{
    public class Conexion
    {
        private string cadenaConexion =
            "Server=(localdb)\\MSSQLLocalDB;Database=PatitasFelicesDB;Trusted_Connection=True;";

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}
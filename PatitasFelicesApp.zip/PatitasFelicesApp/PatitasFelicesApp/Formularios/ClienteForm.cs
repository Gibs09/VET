﻿using PatitasFelicesApp.Controladores;
using PatitasFelicesApp.Modelos;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace PatitasFelicesApp.Formularios
{
    public partial class ClienteForm : Form
    {
        private Usuario usuarioActual;

        public ClienteForm(Usuario usuario)
        {
            InitializeComponent();
            usuarioActual = usuario;

            cmbTipoMascota.Items.Add("Perro");
            cmbTipoMascota.Items.Add("Gato");
            cmbTipoMascota.Items.Add("Ave");
            cmbTipoMascota.Items.Add("Conejo");
            cmbTipoMascota.Items.Add("Otro");

            cmbHora.Items.Add("09:00");
            cmbHora.Items.Add("10:00");
            cmbHora.Items.Add("11:00");
            cmbHora.Items.Add("12:00");
            cmbHora.Items.Add("15:00");
            cmbHora.Items.Add("16:00");
            cmbHora.Items.Add("17:00");
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreDueno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtNombreMascota.Text) ||
                string.IsNullOrWhiteSpace(cmbTipoMascota.Text) ||
                string.IsNullOrWhiteSpace(cmbHora.Text) ||
                string.IsNullOrWhiteSpace(txtMotivo.Text))
            {
                MessageBox.Show("Completa todos los campos.");
                return;
            }

            if (!Regex.IsMatch(txtNombreDueno.Text, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
            {
                MessageBox.Show("El nombre del dueño solo debe contener letras.");
                return;
            }

            if (!Regex.IsMatch(txtNombreMascota.Text, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
            {
                MessageBox.Show("El nombre de la mascota solo debe contener letras.");
                return;
            }

            if (!Regex.IsMatch(txtTelefono.Text, @"^\d{9,12}$"))
            {
                MessageBox.Show("El teléfono debe contener solo números (9 a 12 dígitos).");
                return;
            }

            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Ingresa un correo electrónico válido.");
                return;
            }

            if (dtpFecha.Value.Date < DateTime.Now.Date)
            {
                MessageBox.Show("La fecha de atención no puede ser en el pasado.");
                return;
            }

            try
            {
                Agendamiento agendamiento = new Agendamiento
                {
                    NombreDueno = txtNombreDueno.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim(),
                    Correo = txtCorreo.Text.Trim(),
                    NombreMascota = txtNombreMascota.Text.Trim(),
                    TipoMascota = cmbTipoMascota.Text,
                    EdadMascota = Convert.ToInt32(numEdadMascota.Value),
                    FechaAtencion = dtpFecha.Value.Date,
                    HoraAtencion = cmbHora.Text,
                    MotivoConsulta = txtMotivo.Text.Trim(),
                    Estado = "Pendiente"
                };

                AgendamientoController controller = new AgendamientoController();
                bool resultado = controller.RegistrarAgendamiento(agendamiento);

                if (resultado)
                {
                    MessageBox.Show("Reserva registrada correctamente.");
                    LimpiarCampos();
                }
                else
                {
                    MessageBox.Show("No se pudo registrar la reserva.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LimpiarCampos()
        {
            txtNombreDueno.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtNombreMascota.Clear();
            cmbTipoMascota.SelectedIndex = -1;
            numEdadMascota.Value = 1;
            dtpFecha.Value = DateTime.Now;
            cmbHora.SelectedIndex = -1;
            txtMotivo.Clear();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["AdminForm"] != null)
            {
                this.Close();
            }
            else
            {
                Application.Exit();
            }
        }

        private void ClienteForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Application.OpenForms["AdminForm"] == null)
            {
                Application.Exit();

            }
        }
    }
}
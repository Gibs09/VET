﻿using PatitasFelicesApp.Controladores;
using PatitasFelicesApp.Modelos;
using System;
using System.Windows.Forms;

namespace PatitasFelicesApp.Formularios
{
    public partial class AdminForm : Form
    {
        private Usuario usuarioActual;

        public AdminForm(Usuario usuario)
        {
            InitializeComponent();
            usuarioActual = usuario;
            CargarAgendamientos();

            cmbEstado.Items.Add("Pendiente");
            cmbEstado.Items.Add("Confirmada");
            cmbEstado.Items.Add("Atendida");
            cmbEstado.Items.Add("Cancelada");

            cmbFiltroEstado.Items.Add("General");
            cmbFiltroEstado.Items.Add("Pendiente");
            cmbFiltroEstado.Items.Add("Confirmada");
            cmbFiltroEstado.Items.Add("Atendida");
            cmbFiltroEstado.Items.Add("Cancelada");
        }

        private void CargarAgendamientos()
        {
            try
            {
                AgendamientoController controller = new AgendamientoController();
                dgvAgendamientos.DataSource = controller.ObtenerAgendamientos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            ClienteForm form = new ClienteForm(usuarioActual);
            form.FormClosed += (s, args) => CargarAgendamientos();
            form.ShowDialog();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvAgendamientos.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una reserva.");
                return;
            }

            if (string.IsNullOrWhiteSpace(cmbEstado.Text))
            {
                MessageBox.Show("Selecciona un estado.");
                return;
            }

            int id = Convert.ToInt32(dgvAgendamientos.CurrentRow.Cells["IdAgendamiento"].Value);
            string estado = cmbEstado.Text;

            try
            {
                AgendamientoController controller = new AgendamientoController();
                bool resultado = controller.ActualizarEstado(id, estado);

                if (resultado)
                {
                    MessageBox.Show("Estado actualizado correctamente.");
                    CargarAgendamientos();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el estado.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvAgendamientos.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una reserva.");
                return;
            }

            DialogResult confirm = MessageBox.Show("¿Confirmas eliminar esta reserva?", "Eliminar", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            int id = Convert.ToInt32(dgvAgendamientos.CurrentRow.Cells["IdAgendamiento"].Value);

            try
            {
                AgendamientoController controller = new AgendamientoController();
                bool resultado = controller.EliminarAgendamiento(id);

                if (resultado)
                {
                    MessageBox.Show("Reserva eliminada correctamente.");
                    CargarAgendamientos();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la reserva.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbFiltroEstado.Text))
            {
                MessageBox.Show("Selecciona un filtro.");
                return;
            }

            try
            {
                AgendamientoController controller = new AgendamientoController();
                dgvAgendamientos.DataSource = controller.FiltrarPorEstado(cmbFiltroEstado.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AdminForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
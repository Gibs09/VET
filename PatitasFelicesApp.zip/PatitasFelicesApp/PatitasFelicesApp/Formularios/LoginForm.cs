﻿using PatitasFelicesApp.Controladores;
using PatitasFelicesApp.Formularios;
using PatitasFelicesApp.Modelos;
using System;
using System.Windows.Forms;

namespace PatitasFelicesApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsuario.Text) || string.IsNullOrWhiteSpace(txtContrasena.Text))
            {
                MessageBox.Show("Ingresa usuario y contraseña.");
                return;
            }

            UsuarioController control = new UsuarioController();
            string usuario = txtUsuario.Text.Trim();
            string clave = txtContrasena.Text.Trim();

            Usuario usuarioLogueado = control.ValidarUsuario(usuario, clave);

            if (usuarioLogueado != null)
            {
                MessageBox.Show("Bienvenido " + usuarioLogueado.NombreUsuario);

                if (usuarioLogueado.Rol == "Administrador")
                {
                    AdminForm admin = new AdminForm(usuarioLogueado);
                    admin.Show();
                }
                else if (usuarioLogueado.Rol == "Cliente")
                {
                    ClienteForm cliente = new ClienteForm(usuarioLogueado);
                    cliente.Show();
                }

                this.Hide(); 
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }
    }
}
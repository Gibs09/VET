﻿namespace PatitasFelicesApp.Formularios
{
    partial class ClienteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNombreDueno = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtNombreDueno = new System.Windows.Forms.TextBox();
            this.gbDatosDueno = new System.Windows.Forms.GroupBox();
            this.gbDatosMascota = new System.Windows.Forms.GroupBox();
            this.numEdadMascota = new System.Windows.Forms.NumericUpDown();
            this.cmbTipoMascota = new System.Windows.Forms.ComboBox();
            this.txtNombreMascota = new System.Windows.Forms.TextBox();
            this.lblEdadMascota = new System.Windows.Forms.Label();
            this.lblTipoMascota = new System.Windows.Forms.Label();
            this.lblNombreMascota = new System.Windows.Forms.Label();
            this.gbReserva = new System.Windows.Forms.GroupBox();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.cmbHora = new System.Windows.Forms.ComboBox();
            this.lblHora = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblFecha = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnSalir = new System.Windows.Forms.Button();
            this.gbDatosDueno.SuspendLayout();
            this.gbDatosMascota.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEdadMascota)).BeginInit();
            this.gbReserva.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNombreDueno
            // 
            this.lblNombreDueno.AutoSize = true;
            this.lblNombreDueno.Location = new System.Drawing.Point(17, 54);
            this.lblNombreDueno.Name = "lblNombreDueno";
            this.lblNombreDueno.Size = new System.Drawing.Size(65, 20);
            this.lblNombreDueno.TabIndex = 11;
            this.lblNombreDueno.Text = "Nombre";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(17, 106);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(71, 20);
            this.lblTelefono.TabIndex = 12;
            this.lblTelefono.Text = "Telefono";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Location = new System.Drawing.Point(17, 158);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(57, 20);
            this.lblCorreo.TabIndex = 13;
            this.lblCorreo.Text = "Correo";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(134, 105);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(153, 26);
            this.txtTelefono.TabIndex = 2;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(134, 158);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(153, 26);
            this.txtCorreo.TabIndex = 3;
            // 
            // txtNombreDueno
            // 
            this.txtNombreDueno.Location = new System.Drawing.Point(134, 54);
            this.txtNombreDueno.Name = "txtNombreDueno";
            this.txtNombreDueno.Size = new System.Drawing.Size(153, 26);
            this.txtNombreDueno.TabIndex = 1;
            // 
            // gbDatosDueno
            // 
            this.gbDatosDueno.Controls.Add(this.lblNombreDueno);
            this.gbDatosDueno.Controls.Add(this.txtNombreDueno);
            this.gbDatosDueno.Controls.Add(this.lblTelefono);
            this.gbDatosDueno.Controls.Add(this.txtCorreo);
            this.gbDatosDueno.Controls.Add(this.lblCorreo);
            this.gbDatosDueno.Controls.Add(this.txtTelefono);
            this.gbDatosDueno.Location = new System.Drawing.Point(53, 43);
            this.gbDatosDueno.Name = "gbDatosDueno";
            this.gbDatosDueno.Size = new System.Drawing.Size(307, 243);
            this.gbDatosDueno.TabIndex = 10;
            this.gbDatosDueno.TabStop = false;
            this.gbDatosDueno.Text = "Datos Del Dueño";
            // 
            // gbDatosMascota
            // 
            this.gbDatosMascota.Controls.Add(this.numEdadMascota);
            this.gbDatosMascota.Controls.Add(this.cmbTipoMascota);
            this.gbDatosMascota.Controls.Add(this.txtNombreMascota);
            this.gbDatosMascota.Controls.Add(this.lblEdadMascota);
            this.gbDatosMascota.Controls.Add(this.lblTipoMascota);
            this.gbDatosMascota.Controls.Add(this.lblNombreMascota);
            this.gbDatosMascota.Location = new System.Drawing.Point(53, 292);
            this.gbDatosMascota.Name = "gbDatosMascota";
            this.gbDatosMascota.Size = new System.Drawing.Size(307, 243);
            this.gbDatosMascota.TabIndex = 14;
            this.gbDatosMascota.TabStop = false;
            this.gbDatosMascota.Text = "Datos De La Mascota";
            // 
            // numEdadMascota
            // 
            this.numEdadMascota.Location = new System.Drawing.Point(167, 148);
            this.numEdadMascota.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numEdadMascota.Name = "numEdadMascota";
            this.numEdadMascota.Size = new System.Drawing.Size(120, 26);
            this.numEdadMascota.TabIndex = 6;
            this.numEdadMascota.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmbTipoMascota
            // 
            this.cmbTipoMascota.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoMascota.FormattingEnabled = true;
            this.cmbTipoMascota.Location = new System.Drawing.Point(167, 89);
            this.cmbTipoMascota.Name = "cmbTipoMascota";
            this.cmbTipoMascota.Size = new System.Drawing.Size(121, 28);
            this.cmbTipoMascota.TabIndex = 5;
            // 
            // txtNombreMascota
            // 
            this.txtNombreMascota.Location = new System.Drawing.Point(167, 39);
            this.txtNombreMascota.Name = "txtNombreMascota";
            this.txtNombreMascota.Size = new System.Drawing.Size(121, 26);
            this.txtNombreMascota.TabIndex = 4;
            // 
            // lblEdadMascota
            // 
            this.lblEdadMascota.AutoSize = true;
            this.lblEdadMascota.Location = new System.Drawing.Point(20, 148);
            this.lblEdadMascota.Name = "lblEdadMascota";
            this.lblEdadMascota.Size = new System.Drawing.Size(47, 20);
            this.lblEdadMascota.TabIndex = 17;
            this.lblEdadMascota.Text = "Edad";
            // 
            // lblTipoMascota
            // 
            this.lblTipoMascota.AutoSize = true;
            this.lblTipoMascota.Location = new System.Drawing.Point(20, 96);
            this.lblTipoMascota.Name = "lblTipoMascota";
            this.lblTipoMascota.Size = new System.Drawing.Size(39, 20);
            this.lblTipoMascota.TabIndex = 16;
            this.lblTipoMascota.Text = "Tipo";
            // 
            // lblNombreMascota
            // 
            this.lblNombreMascota.AutoSize = true;
            this.lblNombreMascota.Location = new System.Drawing.Point(20, 45);
            this.lblNombreMascota.Name = "lblNombreMascota";
            this.lblNombreMascota.Size = new System.Drawing.Size(130, 20);
            this.lblNombreMascota.TabIndex = 15;
            this.lblNombreMascota.Text = "Nombre Mascota";
            // 
            // gbReserva
            // 
            this.gbReserva.Controls.Add(this.txtMotivo);
            this.gbReserva.Controls.Add(this.lblMotivo);
            this.gbReserva.Controls.Add(this.cmbHora);
            this.gbReserva.Controls.Add(this.lblHora);
            this.gbReserva.Controls.Add(this.dtpFecha);
            this.gbReserva.Controls.Add(this.lblFecha);
            this.gbReserva.Location = new System.Drawing.Point(53, 547);
            this.gbReserva.Name = "gbReserva";
            this.gbReserva.Size = new System.Drawing.Size(307, 243);
            this.gbReserva.TabIndex = 18;
            this.gbReserva.TabStop = false;
            this.gbReserva.Text = "Datos De La Reserva";
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(101, 148);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(155, 26);
            this.txtMotivo.TabIndex = 9;
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Location = new System.Drawing.Point(26, 148);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(55, 20);
            this.lblMotivo.TabIndex = 21;
            this.lblMotivo.Text = "Motivo";
            // 
            // cmbHora
            // 
            this.cmbHora.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHora.FormattingEnabled = true;
            this.cmbHora.Location = new System.Drawing.Point(101, 88);
            this.cmbHora.Name = "cmbHora";
            this.cmbHora.Size = new System.Drawing.Size(155, 28);
            this.cmbHora.TabIndex = 8;
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Location = new System.Drawing.Point(26, 92);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(44, 20);
            this.lblHora.TabIndex = 20;
            this.lblHora.Text = "Hora";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(101, 39);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(200, 26);
            this.dtpFecha.TabIndex = 7;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(26, 45);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(54, 20);
            this.lblFecha.TabIndex = 19;
            this.lblFecha.Text = "Fecha";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(247, 808);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(155, 40);
            this.btnRegistrar.TabIndex = 22;
            this.btnRegistrar.Text = "Registrar Reserva";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(540, 808);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(107, 40);
            this.btnSalir.TabIndex = 23;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // ClienteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 880);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.gbReserva);
            this.Controls.Add(this.gbDatosMascota);
            this.Controls.Add(this.gbDatosDueno);
            this.Name = "ClienteForm";
            this.Text = "ClienteForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ClienteForm_FormClosing);
            this.gbDatosDueno.ResumeLayout(false);
            this.gbDatosDueno.PerformLayout();
            this.gbDatosMascota.ResumeLayout(false);
            this.gbDatosMascota.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEdadMascota)).EndInit();
            this.gbReserva.ResumeLayout(false);
            this.gbReserva.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNombreDueno;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtNombreDueno;
        private System.Windows.Forms.GroupBox gbDatosDueno;
        private System.Windows.Forms.GroupBox gbDatosMascota;
        private System.Windows.Forms.TextBox txtNombreMascota;
        private System.Windows.Forms.Label lblEdadMascota;
        private System.Windows.Forms.Label lblTipoMascota;
        private System.Windows.Forms.Label lblNombreMascota;
        private System.Windows.Forms.NumericUpDown numEdadMascota;
        private System.Windows.Forms.ComboBox cmbTipoMascota;
        private System.Windows.Forms.GroupBox gbReserva;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.ComboBox cmbHora;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.Button btnRegistrar;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button btnSalir;
    }
}